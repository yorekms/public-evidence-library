# OECD four-country essential-purpose source supplement

The separate frozen module is `oecd_categories_probe.json`, schema `essentials-costs.oecd-categories-probe/v1`. It complements the Eurostat category source module without replacing or rewriting it.

The bounded official OECD query returned Japan in COICOP 2018 (`DSD_NAMAIN10@DF_TABLE5A_T501`, version 2.0), 2000–2024; and USA in 2000–2024 plus Canada and the United Kingdom in 2000–2025 under COICOP 1999 (`DSD_NAMAIN10@DF_TABLE5_T501`, version 1.0). Original full CSV query responses and OECD dataflow/structure XML are retained. The two classifications remain separate.

There are 510 selected original annual purpose cells: domestic total, food/non-alcoholic beverages, housing/water/home energy, electricity/gas/other fuels, and health. The original `OBS_VALUE`, currency, multiplier, status, source coordinates and full native row are preserved. Source units are current national currency, in millions (`UNIT_MULT=6`): USD, CAD, GBP or JPY. Monetary levels are not treated as equal units across currencies.

The native OECD coordinates are annual (`A`), household sector (`S14`), domestic consumption (`P31DC`), current prices (`V`), national currency (`XDC`) and non-transformed data (`N`). Domestic consumption includes spending by residents and nonresidents on the territory. No income subtraction or household budget residual is performed in this module.

An explicit housing-excluding-home-energy value is calculated as `CP04 − CP045`. The selected-purpose shares are `100 × category / TOTAL`; for housing excluding home energy the formula is `100 × (CP04 − CP045) / TOTAL`. All exact-country/year original inputs and raw source references are retained; housing-share inputs include the original CP04, CP045 and TOTAL amounts. These are shares of domestic household consumption, not shares of resident disposable income or minimum-needs standards. The module also keeps total and inclusive-housing shares as supporting context.

The four desired map-series categories are `CP01`, `HOUSING_EX_HOME_ENERGY`, `CP045` and `CP06`. Their IDs follow `derived::{dataflow}::SHARE_DOMESTIC_CONSUMPTION::{category}`. Native monetary series follow `oecd::{dataflow}::CURRENT_MILLION_NAC::{category}`. Definition and classification fields must stay visible when comparing sources.

The module includes 1,224 records: 510 native monetary cells, 102 calculated housing differences and 612 calculated shares. `qa/OECD_CATEGORIES_PROBE_READBACK.json` checks all original core values and all derived calculations directly against the retained raw CSV rows. The normalization script is `scripts/build_oecd_categories_probe.py`; retrieval URLs and hashes are in `OECD_CATEGORIES_SOURCE_INDEX.json`. The source COICOP totals include imputed housing services and compiled estimates, rather than only cash bills.

Official source explorer: [COICOP 2018 household purpose accounts](https://data-explorer.oecd.org/vis?df%5Bag%5D=OECD.SDD.NAD&df%5Bid%5D=DSD_NAMAIN10%40DF_TABLE5A_T501&df%5Bvs%5D=2.0), and [legacy household purpose accounts](https://data-explorer.oecd.org/vis?df%5Bag%5D=OECD.SDD.NAD&df%5Bid%5D=DSD_NAMAIN10%40DF_TABLE5_T501&df%5Bvs%5D=1.0).
