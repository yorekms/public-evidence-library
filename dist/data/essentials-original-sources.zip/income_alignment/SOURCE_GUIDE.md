# Resident household income and national/domestic consumption bridge

This is a source module for the essentials-cost comparison. It retains original annual Eurostat national-account values for 2000–2025. The module does not itself subtract category spending or convert income into a household cash budget.

## Core income and consumption measures

- **Households (S14), gross disposable income (B6G), received (RECV):** resources after direct taxes and transfers according to the ESA 2010 account, before consumption of fixed capital. Original current prices, million EUR (`CP_MEUR`) and million national-currency units (`CP_MNAC`) remain separate.
- **Households (S14), final consumption expenditure (P3), paid (PAID):** resident household final consumption, on the national concept. S14 expenditure is individual household consumption. It excludes social transfers in kind supplied by government/NPISH and includes national-account imputations such as owner-occupied housing services.
- **Net disposable income (B6N):** the alternative after deduction of consumption of fixed capital. It remains a distinct original series; the gross and net bases are not silently mixed.
- **Gross saving (B8G)** and **adjustment for the change in pension entitlements (D8, paid and received)** are retained for accounting context. B6G minus selected spending is not the official saving rate: other consumption remains, and the saving-account identity also includes the pension adjustment.
- **Households plus NPISH (S14_S15)** values are retained as separate contextual originals. They must not substitute for S14 when matching household-only consumption categories.

The core S14 B6G and S14 P3 EUR series each have 760 numerical country-years across 32 economies. The module contains 34 series, 30,472 cells (26,726 numerical), and the union of 38 source countries. Country and year coverage varies by series. Missing source cells stay null.

Source sector-account update: `2026-10-29T23:00:00+0100`. Original status codes such as provisional (`p`) and break in time series (`b`) remain attached. An unflagged source cell is still a compiled national-account estimate, not a certification of direct measurement.

## Why domestic categories cannot be directly subtracted from resident income

Eurostat COICOP category expenditure (`nama_10_cp18`, COICOP 2018) covers household purchases **on the domestic territory**, including nonresident purchases and excluding residents' purchases abroad. Household sector income and resident household P3 use resident institutional units. The source metadata explicitly distinguishes them.

A transparent model can estimate resident category costs as:

```text
estimated resident category spending = resident household P3
                                      × domestic category spending / domestic TOTAL
```

This assumes the same category composition for resident expenditure as for the observed domestic total. It is an analyst allocation assumption, not an observed resident category amount. It can be useful for a labeled accounting comparison but should remain separate from the original domestic category values. Apply only to same-country, same-year, compatible current-price units and valid inputs; do not fill missing categories or mix chain-linked volume components.

The corresponding remainder is gross disposable income less the estimated nonoverlapping essential categories. It describes aggregate resources remaining for all other consumption/saving before depreciation. It is not median household income, a minimum-needs budget, a cash balance, an official saving rate or a causal prediction. A percentage of B6G is a size-normalized accounting comparison; current-EUR totals retain exchange-rate and inflation effects.

## Observed tourism bridge and optional allocation bounds

The module retains original `nama_10_fcs` values:

| Code | Scope |
| --- | --- |
| P31_S14_DC | Domestic household final consumption |
| P31_S14_NC | Resident/national household final consumption |
| P33 | Resident household consumption in the rest of the world |
| P34 | Nonresident household consumption on the domestic territory |

The accounting relationship is `national = domestic + P33 − P34`. In the retained data, all 3,620 numerical P33/P34 current-EUR/national-currency cells are nonnegative expenditure magnitudes.

If selected domestic category expenditure is D, resident total is R, residents' expenditure abroad is O and nonresidents' domestic expenditure is I, a purely accounting allocation range can use:

```text
resident selected spending lower bound = max(0, D − I)
resident selected spending upper bound = min(R, D + O)
```

This follows from the extreme possibilities that none or all of each cross-border total belongs to the selected categories. It is an accounting constraint under coherent aggregate scopes, not a confidence interval, credible interval, observed category distribution or empirical estimate of travel effects. A remainder interval reverses the cost endpoints: `[income − upper cost, income − lower cost]`.

These bounds must be unavailable when source coherence fails: the FCS national/domestic/tourism identity must hold, FCS national spending must match the resident P3 used in the model, and FCS domestic spending must match the category dataset's domestic TOTAL, subject only to an explicitly stated source-precision tolerance. Do not force equality, rescale original observations or interpret cross-vintage discrepancies as actual tourism effects.

Observed coherence is imperfect. Of 905 current-EUR country-years with all four FCS bridge terms, 654 identities are equal within numerical tolerance 1e−8; 251 have a nonzero residual. The largest residual is Norway 2023, −1,388.1 million EUR. Resident sector-account P3 and FCS national spending match exactly in 158 of 758 jointly available cells; the largest absolute cross-table difference is Switzerland 2023, about −3,105.4 million EUR (FCS less sector account). Every difference is retained in `BRIDGE_COHERENCE.csv` and summarized in the independent readback. The central proportional allocation remains an explicit mixed-source estimate; bounds require the stronger coherence checks above.

## Original sources and reproduction

Official primary documentation:

- [Annual sector accounts metadata](https://ec.europa.eu/eurostat/cache/metadata/en/nasa_10_nf_tr_esms.htm): sector definitions, gross/net distinction, accrual accounting, transaction directions and source revisions.
- [COICOP 2018 household-consumption metadata](https://ec.europa.eu/eurostat/cache/metadata/en/nama_10_cp18_esms.htm): domestic scope, national/domestic identity, exclusions and imputed components, current-price units, and chain-linked-volume nonadditivity.
- [Annual national accounts metadata](https://ec.europa.eu/eurostat/cache/metadata/en/nama10_esms.htm): classifications and possible vintage-related discrepancies.

`SOURCE_INDEX.json` records every exact API URL, original response filename, byte count, hash and retrieval time. The original `nama_10_gdp` P31_S14 response is retained as an additional resident-consumption cross-check. It is not substituted for a missing sector-account cell. JSON-stat flat indices and coordinate codes in each normalized record identify its exact original numerical value and status.

Reproduction: run `acquire_income_alignment.py`, then `add_bridge.py` in a new versioned copy of this folder. Both use free public Eurostat APIs. `income_values.csv` contains the original sector-account selection; `income_and_bridge_values.csv` includes the additional bridge originals. `INDEPENDENT_READBACK.json` and `independent_readback.py` provide original-byte and coordinate/value verification plus the unforced bridge differences.
