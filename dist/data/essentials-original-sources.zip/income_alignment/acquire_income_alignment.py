"""Archive Eurostat resident household income and consumption for scope alignment."""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
from itertools import product
import csv
import hashlib
import json
import math
import requests

ROOT = Path(__file__).resolve().parent
BASE = 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/'
GEO = {'BE':'BEL','BG':'BGR','CZ':'CZE','DK':'DNK','DE':'DEU','EE':'EST','IE':'IRL','EL':'GRC','ES':'ESP','FR':'FRA','HR':'HRV','IT':'ITA','CY':'CYP','LV':'LVA','LT':'LTU','LU':'LUX','HU':'HUN','MT':'MLT','NL':'NLD','AT':'AUT','PL':'POL','PT':'PRT','RO':'ROU','SI':'SVN','SK':'SVK','FI':'FIN','SE':'SWE','IS':'ISL','CH':'CHE','AL':'ALB','RS':'SRB','TR':'TUR','UA':'UKR','NO':'NOR','UK':'GBR','ME':'MNE','MK':'MKD','BA':'BIH','XK':'XKX'}


def archive(name, url, params=None):
    response = requests.get(url, params=params, timeout=90)
    response.raise_for_status()
    raw = response.content
    (ROOT/name).write_bytes(raw)
    return {'id':'eurostat:'+name, 'title':name, 'file':'income_alignment/'+name,
            'url':response.url, 'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest(),
            'retrieved_utc':datetime.now(timezone.utc).isoformat()}


def cells(data):
    ids, sizes = data['id'], data['size']
    dimensions = data['dimension']
    indices = [[code for code, number in sorted(dimensions[k]['category']['index'].items(),key=lambda p:p[1])] for k in ids]
    stride = [math.prod(sizes[j+1:]) for j in range(len(sizes))]
    for positions in product(*(range(size) for size in sizes)):
        flat = sum(p*s for p,s in zip(positions,stride))
        codes = {k:indices[n][positions[n]] for n,k in enumerate(ids)}
        yield flat, codes, data.get('value',{}).get(str(flat)), data.get('status',{}).get(str(flat),'')


def main():
    params = [('lang','en'),('freq','A'),('unit','CP_MEUR'),('unit','CP_MNAC'),('sector','S14'),('sector','S14_S15')]
    params += [('na_item',k) for k in ['B6G','B6N','P3','B8G','D8']]
    params += [('sinceTimePeriod','2000'),('untilTimePeriod','2025')]
    requests_to_make = [
        ('nasa_resident_household_accounts.json', BASE+'nasa_10_nf_tr', params),
        ('gdp_resident_household_consumption.json',BASE+'nama_10_gdp', [('lang','en'),('freq','A'),('unit','CP_MEUR'),('unit','CP_MNAC'),('na_item','P31_S14'),('sinceTimePeriod','2000'),('untilTimePeriod','2025')]),
        ('sector_accounts_metadata.html','https://ec.europa.eu/eurostat/cache/metadata/en/nasa_10_nf_tr_esms.htm',None),
        ('national_accounts_metadata.html','https://ec.europa.eu/eurostat/cache/metadata/en/nama10_esms.htm',None),
        ('coicop2018_metadata.html','https://ec.europa.eu/eurostat/cache/metadata/en/nama_10_cp18_esms.htm',None),
    ]
    with ThreadPoolExecutor(max_workers=5) as executor:
        sources = list(executor.map(lambda q:archive(*q), requests_to_make))
    source = sources[0]
    data = json.loads((ROOT/'nasa_resident_household_accounts.json').read_text())
    if data.get('error'):
        raise RuntimeError(data['error'])
    wanted = [('B6G','RECV'),('B6N','RECV'),('P3','PAID'),('B8G','RECV'),('D8','PAID'),('D8','RECV')]
    definitions = []
    for unit,sector,(item,direct) in product(['CP_MEUR','CP_MNAC'], ['S14','S14_S15'], wanted):
        name = data['dimension']['na_item']['category']['label'][item]
        sector_label = data['dimension']['sector']['category']['label'][sector]
        unit_label = data['dimension']['unit']['category']['label'][unit]
        series_id = 'eurostat::nasa_10_nf_tr::'+':'.join([sector,item,direct,unit])
        definitions.append({'id':series_id,'label':name+' · '+sector_label+' · '+direct.lower(),
                            'unit':unit_label,'unit_code':unit,'sector':sector,'sector_label':sector_label,
                            'na_item':item,'direct':direct,'concept':'resident_household_income' if item in {'B6G','B6N'} else 'resident_household_accounts',
                            'geographic_scope':'national/resident institutional units',
                            'gross_or_net':'gross before consumption of fixed capital' if item.endswith('G') else 'net after consumption of fixed capital' if item.endswith('N') else 'source-defined transaction',
                            'frequency':'annual','cross_country_eligible':False,'temporal_eligible':True,
                            'source_ids':[source['id']],'adjustment':'Original published current-price national account; no local conversion or gap fill',
                            'definition':name+' of '+sector_label+'; ESA 2010, original '+unit_label+'. Accrual basis, including household national-account imputations.'})
    definition_ids = {d['id'] for d in definitions}
    rows, exclusions = [], []
    labels = data['dimension']['geo']['category']['label']
    for flat,codes,value,flag in cells(data):
        series_id = 'eurostat::nasa_10_nf_tr::'+':'.join(codes[k] for k in ['sector','na_item','direct','unit'])
        if series_id not in definition_ids:
            continue
        geo = codes['geo']
        if geo not in GEO:
            exclusions.append({'flat_index':flat,'reason':'source region aggregate retained only in raw response','geo':geo})
            continue
        rows.append({'series_id':series_id,'geo_id':GEO[geo],'geo_name':labels[geo],'native_geo':geo,
                     'year':int(codes['time']),'source_year':int(codes['time']),'value':value,
                     'unit':data['dimension']['unit']['category']['label'][codes['unit']],
                     'unit_code':codes['unit'],'status':'source_missing' if value is None else 'published_national_account_estimate',
                     'status_label':'Unavailable in source' if value is None else 'Published national-account estimate'+('; native flags: '+flag if flag else ''),
                     'native_obs_status':flag,'estimate':True,'derived_locally':False,'eligible':value is not None,
                     'source_id':source['id'],'source_record_ref':{'file':source['file'],'flat_index':flat,'value_pointer':'/value/'+str(flat),'dimensions':codes},
                     'source_record_refs':[{'file':source['file'],'flat_index':flat,'value_pointer':'/value/'+str(flat),'dimensions':codes}],
                     'native_fields':codes,'sector':codes['sector'],'na_item':codes['na_item'],'direct':codes['direct'],
                     'geographic_scope':'resident institutional units','comparability_group':codes['sector']+'::'+codes['na_item']+'::'+codes['direct']+'::'+codes['unit']})
    packet = {'schema':'essentials-costs.income-alignment-source/v1','prepared_utc':datetime.now(timezone.utc).isoformat(),
              'series':definitions,'countries':[{'id':GEO[k],'name':labels[k],'native_id':k} for k in labels if k in GEO],
              'records':rows,'sources':sources,'source_updated':data.get('updated'),
              'coverage':{'series':len(definitions),'records':len(rows),'numeric_records':sum(r['value'] is not None for r in rows),'country_count':len({r['geo_id'] for r in rows}),'years':[2000,2025],
                          'core_S14_B6G_EUR_values':sum(r['value'] is not None and r['sector']=='S14' and r['na_item']=='B6G' and r['unit_code']=='CP_MEUR' for r in rows),
                          'core_S14_P3_EUR_values':sum(r['value'] is not None and r['sector']=='S14' and r['na_item']=='P3' and r['unit_code']=='CP_MEUR' for r in rows)},
              'limitations':['COICOP category expenditure is domestic; resident S14 income and consumption are national. Direct subtraction of domestic category amounts from resident income is blocked.',
                              'A proportional resident allocation uses resident S14 P3 multiplied by domestic category expenditure / domestic TOTAL. The identical domestic/resident category mix is an analyst assumption, not an observed resident category cost.',
                              'Gross disposable income includes consumption of fixed capital and imputed items; it is not household cash income. Any derived remainder is remaining aggregate resources for other consumption/saving before depreciation, not a median budget or official saving rate.',
                              'S14 (households) is separate from S14_S15 (households plus NPISH); no substitution is permitted. Social transfers in kind are excluded from B6G and ordinary household final consumption; B7G is not used.',
                              'Nominal current-price EUR and national-currency totals are preserved; cross-country purchasing-power comparison requires a documented additional adjustment.','Native provisional and break flags remain attached; source data can be revised and cross-dataset vintages can differ.']}
    (ROOT/'income_module.json').write_text(json.dumps(packet,ensure_ascii=False,separators=(',',':'))+'\n')
    (ROOT/'SOURCE_INDEX.json').write_text(json.dumps({'sources':sources,'status_labels':data.get('extension',{}).get('status'), 'source_updated':data.get('updated')},ensure_ascii=False,indent=2)+'\n')
    (ROOT/'EXCLUSION_LEDGER.json').write_text(json.dumps(exclusions,indent=2)+'\n')
    columns = ['series_id','geo_id','geo_name','year','value','unit','sector','na_item','direct','native_obs_status','source_record_ref']
    with (ROOT/'income_values.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
        for row in rows:writer.writerow({k:json.dumps(row[k],ensure_ascii=False) if isinstance(row[k],dict) else row[k] for k in columns})
    print(json.dumps(packet['coverage'],indent=2))


if __name__=='__main__':
    main()
