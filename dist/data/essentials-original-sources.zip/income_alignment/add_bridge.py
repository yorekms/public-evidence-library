"""Add independently sourced tourism/national-domestic bridge originals."""
from pathlib import Path
import json
from acquire_income_alignment import archive, cells, GEO, BASE

ROOT=Path(__file__).resolve().parent
data_path=ROOT/'income_module.json'
packet=json.loads(data_path.read_text())
if any(s['id']=='eurostat:household_national_domestic_bridge.json' for s in packet['sources']):
    raise SystemExit('Bridge is already retained. Rebuild the base module before adding a newly acquired bridge edition.')
params=[('lang','en'),('freq','A'),('unit','CP_MEUR'),('unit','CP_MNAC')]
params += [('na_item',k) for k in ['P31_S14','P31_S14_DC','P31_S14_NC','P33','P34']]
params += [('sinceTimePeriod','2000'),('untilTimePeriod','2025')]
source=archive('household_national_domestic_bridge.json',BASE+'nama_10_fcs',params)
data=json.loads((ROOT/'household_national_domestic_bridge.json').read_text())
if data.get('error'):raise RuntimeError(data['error'])
packet['sources'].append(source)
definitions=[]
for unit in data['dimension']['unit']['category']['index']:
 for item,label in data['dimension']['na_item']['category']['label'].items():
  scope=('domestic household consumption' if item=='P31_S14_DC' else 'resident household purchases abroad' if item=='P33' else 'nonresident household purchases on domestic territory' if item=='P34' else 'national/resident household consumption')
  definitions.append({'id':'eurostat::nama_10_fcs::'+unit+'::'+item,'label':label,
                      'unit':data['dimension']['unit']['category']['label'][unit],
                      'unit_code':unit,'sector':'S14','na_item':item,
                      'geographic_scope':scope,'frequency':'annual','cross_country_eligible':False,
                      'source_ids':[source['id']],'adjustment':'Original published national-account bridge flow; no local conversion',
                      'definition':label+'; ESA 2010 household consumption. The national/domestic difference is linked to resident purchases abroad and nonresident purchases on the domestic territory.'})
packet['series'].extend(definitions)
for flat,codes,value,flag in cells(data):
 geo=codes['geo']
 if geo not in GEO:continue
 sid='eurostat::nama_10_fcs::'+codes['unit']+'::'+codes['na_item']
 definition=next(s for s in definitions if s['id']==sid)
 ref={'file':source['file'],'flat_index':flat,'value_pointer':'/value/'+str(flat),'dimensions':codes}
 packet['records'].append({'series_id':sid,'geo_id':GEO[geo],'geo_name':data['dimension']['geo']['category']['label'][geo],
                            'native_geo':geo,'year':int(codes['time']),'source_year':int(codes['time']),
                            'value':value,'unit':definition['unit'],'unit_code':codes['unit'],
                            'status':'source_missing' if value is None else 'published_national_account_estimate',
                            'status_label':'Unavailable in source' if value is None else 'Published national-account bridge flow'+('; native flags: '+flag if flag else ''),
                            'native_obs_status':flag,'estimate':True,'eligible':value is not None,'derived_locally':False,
                            'source_id':source['id'],'source_record_ref':ref,'source_record_refs':[ref],
                            'native_fields':codes,'sector':'S14','na_item':codes['na_item'],
                            'geographic_scope':definition['geographic_scope'],
                            'comparability_group':'FCS::S14::'+codes['na_item']+'::'+codes['unit']})
for geo,label in data['dimension']['geo']['category']['label'].items():
 if geo in GEO and not any(c['id']==GEO[geo] for c in packet['countries']):packet['countries'].append({'id':GEO[geo],'name':label,'native_id':geo})
packet['coverage'].update(series=len(packet['series']),records=len(packet['records']),numeric_records=sum(r['value']is not None for r in packet['records']),country_count=len(packet['countries']))
packet['limitations'].append('Separate national/domestic bridge originals are retained. They can bound tourism-related allocation differences, but do not identify the category composition of resident and nonresident cross-border purchases. Cross-dataset vintages can differ.')
data_path.write_text(json.dumps(packet,ensure_ascii=False,separators=(',',':'))+'\n')
index=json.loads((ROOT/'SOURCE_INDEX.json').read_text());index['sources'].append(source);index['bridge_source_updated']=data.get('updated');(ROOT/'SOURCE_INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'bridge_source_bytes':source['bytes'],'bridge_numeric_cells':len(data.get('value',{})),'final_coverage':packet['coverage']},indent=2))
