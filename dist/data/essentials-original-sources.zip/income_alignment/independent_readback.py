"""Independent original-byte/JSON-stat coordinate audit; no acquisition helpers imported."""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parent
packet=json.loads((ROOT/'income_module.json').read_text())
raws={}
failures=[]
for source in packet['sources']:
    file=ROOT.parent/source['file'];raw=file.read_bytes()
    if len(raw)!=source['bytes']or hashlib.sha256(raw).hexdigest()!=source['sha256']:
        failures.append({'source':source['file'],'problem':'original-byte hash/size mismatch'})
    if file.suffix=='.json':raws[source['file']]=json.loads(raw)
checks=0
for row in packet['records']:
    ref=row['source_record_ref'];raw=raws[ref['file']];flat=ref['flat_index']
    if row['value']!=raw.get('value',{}).get(str(flat)):
        failures.append({'series':row['series_id'],'geo':row['geo_id'],'year':row['year'],'problem':'value mismatch'})
    checks+=1
    if row['native_obs_status']!=raw.get('status',{}).get(str(flat),''):
        failures.append({'series':row['series_id'],'geo':row['geo_id'],'year':row['year'],'problem':'native-status mismatch'})
    checks+=1
    remainder=flat
    for position,key in enumerate(raw['id']):
        stride=math.prod(raw['size'][position+1:]);index=remainder//stride;remainder%=stride
        category=next(k for k,v in raw['dimension'][key]['category']['index'].items()if v==index)
        if row['native_fields'][key]!=category or ref['dimensions'][key]!=category:
            failures.append({'flat':flat,'dimension':key,'problem':'coordinate mismatch'})
        checks+=1
keys=[(r['series_id'],r['geo_id'],r['year'])for r in packet['records']]
if len(keys)!=len(set(keys)):failures.append({'problem':'duplicate normalized key'})

def native_cells(raw):
    # Decode numeric cells only with successive quotient/remainder coordinates.
    for index,value in raw.get('value',{}).items():
        flat=int(index);left=flat;codes={}
        for n,dim in enumerate(raw['id']):
            stride=math.prod(raw['size'][n+1:]);loc=left//stride;left%=stride
            codes[dim]=next(k for k,v in raw['dimension'][dim]['category']['index'].items()if v==loc)
        yield codes,value

gdp={}
for c,v in native_cells(json.loads((ROOT/'gdp_resident_household_consumption.json').read_text())):
    if c['unit']=='CP_MEUR':gdp[(c['geo'],int(c['time']))]=v
sector={(r['native_geo'],r['year']):r['value']for r in packet['records']if r['na_item']=='P3'and r['sector']=='S14'and r['unit_code']=='CP_MEUR'and r['value']is not None}
bridge={}
for r in packet['records']:
    if '::nama_10_fcs::'in r['series_id']and r['unit_code']=='CP_MEUR':
        bridge.setdefault((r['native_geo'],r['geo_id'],r['year']),{})[r['na_item']]=r['value']
rows=[]
for(native,iso,year),d in sorted(bridge.items()):
    dc,nc,outside,inside=[d.get(k)for k in ['P31_S14_DC','P31_S14_NC','P33','P34']]
    all_four=all(v is not None for v in [dc,nc,outside,inside])
    sr=sector.get((native,year));gr=gdp.get((native,year))
    rows.append({'geo_id':iso,'native_geo':native,'year':year,'unit':'Current prices, million euro',
                 'FCS_domestic_total':dc,'FCS_resident_total':nc,'P33_residents_abroad':outside,'P34_nonresident_domestic':inside,
                 'FCS_identity_residual':nc-(dc+outside-inside)if all_four else None,
                 'FCS_identity_exact_1e_minus8':abs(nc-(dc+outside-inside))<=1e-8 if all_four else None,
                 'sector_S14_P3':sr,'FCS_minus_sector_resident_total':nc-sr if nc is not None and sr is not None else None,
                 'GDP_resident_household_P31':gr,'FCS_minus_GDP_resident_total':nc-gr if nc is not None and gr is not None else None})
with(ROOT/'BRIDGE_COHERENCE.csv').open('w',newline='')as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def summary(key):
    valid=[r for r in rows if r[key]is not None]
    worst=max(valid,key=lambda r:abs(r[key]))if valid else None
    return {'matched_cells':len(valid),'exact_within_1e_minus8':sum(abs(r[key])<=1e-8 for r in valid),
            'nonzero_residuals_retained':sum(abs(r[key])>1e-8 for r in valid),
            'largest_absolute_difference':{k:worst[k]for k in ['geo_id','year',key]}if worst else None}
flow_rows=[r for r in packet['records']if r['na_item']in['P33','P34']and r['value']is not None]
negative=[r for r in flow_rows if r['value']<0]
if negative:failures.append({'problem':'negative gross tourism expenditure flows','records':len(negative)})
receipt={'schema':'essentials-costs.income-alignment-readback/v1','packet_bytes':(ROOT/'income_module.json').stat().st_size,
         'packet_sha256':hashlib.sha256((ROOT/'income_module.json').read_bytes()).hexdigest(),
         'source_files_hash_verified':len(packet['sources']),'native_records_verified':len(packet['records']),
         'native_field_checks':checks,'duplicate_native_keys':len(keys)-len(set(keys)),
         'numeric_tourism_flow_cells':len(flow_rows),'negative_tourism_flow_cells':len(negative),
         'bridge_internal_identity':summary('FCS_identity_residual'),
         'bridge_vs_sector_resident_consumption':summary('FCS_minus_sector_resident_total'),
         'bridge_vs_GDP_resident_consumption':summary('FCS_minus_GDP_resident_total'),
         'failures':failures,'source_coherence_differences_are_not_extraction_failures':True,
         'bound_formula_validity':'With nonnegative category and cross-border totals, and coherent scopes/aggregate identity: resident selected costs in [max(0,D-I),min(R,D+O)]. This is an allocation constraint, not statistical uncertainty.',
         'all_values_left_unforced':True}
(ROOT/'INDEPENDENT_READBACK.json').write_text(json.dumps(receipt,indent=2)+'\n')
columns=['series_id','geo_id','geo_name','year','value','unit','sector','na_item','native_obs_status','source_record_ref']
with(ROOT/'income_and_bridge_values.csv').open('w',newline='')as f:
    writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
    for r in packet['records']:writer.writerow({k:json.dumps(r.get(k),ensure_ascii=False)if isinstance(r.get(k),dict)else r.get(k)for k in columns})
print(json.dumps(receipt,indent=2))
if failures:raise SystemExit(1)
