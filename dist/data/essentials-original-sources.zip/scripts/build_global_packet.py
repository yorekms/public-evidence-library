"""Add sourced OECD category shares to the frozen global context without mixing budgets."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[1]


def build():
    original = ROOT/'global_context/global_context_module.json'
    oecd = ROOT/'oecd_categories_probe.json'
    data = json.loads(original.read_text())
    extra = json.loads(oecd.read_text())
    for series in data['series']:
        if series['id'] == 'fpn::CoHD_headcount':
            series['estimate_note'] = (series.get('estimate_note', '') +
                ' Publisher metadata has a wording inconsistency: the indicator title identifies healthy-diet unaffordability, while its retained long definition refers to energy-sufficient food. Consult the original metadata and source guide before interpreting the threshold.').strip()
    selected = {s['id'] for s in extra['series']
                if '::SHARE_DOMESTIC_CONSUMPTION::' in s['id']
                and s.get('source_category') in {'CP01', 'HOUSING_EX_HOME_ENERGY', 'CP045', 'CP06'}}
    for r in data['records']:
        r['source_record_base'] = 'global_context'
    for s in extra['series']:
        if s['id'] not in selected:
            continue
        s = copy.deepcopy(s)
        s.update(residual_eligible=False, temporal_eligible=True,
                 estimate_note='Calculated share of compiled national accounts. Country financing conventions remain in the source; healthcare-purpose spending is not an out-of-pocket bill.')
        data['series'].append(s)
    for r in extra['records']:
        if r['series_id'] not in selected:
            continue
        r = copy.deepcopy(r)
        r.update(residual_eligible=False, source_record_base='.')
        data['records'].append(r)
    data['sources'].extend(copy.deepcopy(extra['sources']))
    data['sources'].append({'id': 'derived:oecd:categories', 'title': 'Explicit domestic household category-share calculations',
                            'url': 'https://data-explorer.oecd.org/', 'file': 'oecd_categories_probe.json'})
    names = {c['id']: c['name'] for c in data['countries']}
    for c in extra['countries']:
        names.setdefault(c['id'], c['name'])
    data['countries'] = [{'id': k, 'name': v} for k, v in sorted(names.items(), key=lambda p:p[1])]
    data['limitations'].extend([
        'OECD domestic category shares are ratios of category expenditure to total domestic household consumption, not shares of resident income. They do not supply an income remainder.',
        'COICOP 2018 and COICOP 1999 share series remain separate. Current national-currency amounts cancel within the same country/year ratio; currencies are never treated as equal amounts.',
        'Healthcare-purpose consumption follows national-account financing conventions. It is distinct from out-of-pocket healthcare and should not be presented as a household cash bill.',
        'For original World Bank/FAO records, source_record_ref resolves relative to global_context/ in the source ZIP. Added OECD references resolve relative to the ZIP root; source_record_base records this explicitly.',
    ])
    keys = [(r['series_id'],r['geo_id'],r['year']) for r in data['records']]
    if len(keys) != len(set(keys)):
        raise ValueError('Duplicate global source keys.')
    counts = {}
    for s in data['series']:
        rows = [r for r in data['records'] if r['series_id'] == s['id']]
        usable = [r for r in rows if isinstance(r.get('value'),(int,float)) and not isinstance(r['value'],bool) and math.isfinite(r['value']) and r.get('eligible') is not False]
        counts[s['id']] = {'records':len(rows),'numerical_values':len(usable),'economies_with_values':len({r['geo_id'] for r in usable})}
    data['prepared_utc'] = datetime.now(timezone.utc).isoformat()
    data['methods'] = {'source_modules':[{'file':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [original,oecd]],
                       'all_series_residual_eligible':False,'published_current_PPP_not_redeflated':True}
    data['coverage'] = {'series':len(data['series']),'records':len(data['records']),
                        'numerical_values':sum(v['numerical_values']for v in counts.values()),'by_series':counts}
    raw=(json.dumps(data,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    (ROOT/'global_context.json').write_bytes(raw)
    m={'schema':data['schema'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'coverage':data['coverage']}
    (ROOT/'GLOBAL_MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
    print(json.dumps(m,indent=2))


if __name__=='__main__':
    build()
