"""Normalize the bounded official OECD four-country category probe, separately."""
from pathlib import Path
import csv
import hashlib
import json
from datetime import datetime,timezone
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
COUNTRIES={'USA':'United States','CAN':'Canada','GBR':'United Kingdom','JPN':'Japan'}
LABELS={'_T':'Total domestic household consumption','CP01':'Food and non-alcoholic beverages',
        'CP04':'Housing, water and home energy','CP045':'Electricity, gas and other fuels',
        'CP06':'Health','HOUSING_EX_HOME_ENERGY':'Housing and water excluding home energy'}
DATA=[('oecd_table5a2018_four_countries.csv','DSD_NAMAIN10@DF_TABLE5A_T501','2.0','COICOP 2018'),
      ('oecd_table5a1999_four_countries.csv','DSD_NAMAIN10@DF_TABLE5_T501','1.0','COICOP 1999')]


def run():
    records=[];sources=[];series=[];raw_by_file={}
    for filename,flow,version,classification in DATA:
        path=ROOT/'sources'/filename;b=path.read_bytes();rows=list(csv.DictReader(path.open()))
        raw_by_file[filename]=rows
        key=['A','USA+CAN+JPN+GBR','','','','','','','','V','','']
        url='https://sdmx.oecd.org/public/rest/v1/data/OECD.SDD.NAD,'+flow+','+version+'/'+'.'.join(key)+'?startPeriod=2000&endPeriod=2025&format=csvfile'
        source_id='oecd:categories:'+flow
        sources.append({'id':source_id,'title':'OECD annual household consumption by purpose · '+classification,
                        'url':url,'file':'sources/'+filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
                        'dataflow':flow,'version':version,'classification':classification,
                        'method_url':'https://data-explorer.oecd.org/vis?df[ag]=OECD.SDD.NAD&df[id]='+flow+'&df[vs]='+version})
        for category in LABELS:
            sid=f'oecd::{flow}::CURRENT_MILLION_NAC::{category}'
            series.append({'id':sid,'label':LABELS[category]+' · '+classification+' · current national currency, millions',
                           'unit':'current national currency, millions','dataset_id':flow,'classification':classification,
                           'source_category':category,'concept':category,'source_ids':[source_id],
                           'definition':'Domestic household S14 final consumption (P31DC), current prices, in the source national currency and source unit multiplier 6. Includes residents and nonresidents on the territory.',
                           'adjustment':'Original OECD value'if category!='HOUSING_EX_HOME_ENERGY'else'Calculated CP04 − CP045 from same-country/year/current-currency originals',
                           'sector':'S14','territorial_basis':'domestic','frequency':'annual','cross_country_eligible':False,
                           'estimate_note':'Compiled national-account statistics; native observation status and source rows retained.'})
        for index,row in enumerate(rows):
            category=row['EXPENDITURE']
            if category not in LABELS or category=='HOUSING_EX_HOME_ENERGY':continue
            if not(row['FREQ']=='A'and row['SECTOR']=='S14'and row['TRANSACTION']=='P31DC'and row['PRICE_BASE']=='V'and row['UNIT_MEASURE']=='XDC'and row['TRANSFORMATION']=='N'and row['UNIT_MULT']=='6'):
                raise ValueError('Unexpected OECD purpose coordinates')
            value=float(row['OBS_VALUE'])if row['OBS_VALUE']else None
            ref={'file':'sources/'+filename,'row_index':index,'value_field':'OBS_VALUE'}
            records.append({'series_id':f'oecd::{flow}::CURRENT_MILLION_NAC::{category}',
                            'geo_id':row['REF_AREA'],'geo_name':COUNTRIES[row['REF_AREA']],
                            'year':int(row['TIME_PERIOD']),'value':value,'native_value_text':row['OBS_VALUE'],
                            'unit':'current national currency, millions','currency':row['CURRENCY'],
                            'native_unit_code':row['UNIT_MEASURE'],'unit_multiplier':int(row['UNIT_MULT']),
                            'native_obs_status':row['OBS_STATUS'],'status':'published_national_account_estimate',
                            'status_label':'Published domestic household-consumption estimate',
                            'source_id':source_id,'source_record_ref':ref,'source_record_refs':[ref],
                            'source_record':row,'classification':classification,'source_category':category,
                            'dataset_id':flow,'sector':'S14','territorial_basis':'domestic','eligible':value is not None,
                            'estimate':True,'derived_locally':False,'comparability_group':flow+'::'+row['REF_AREA']+'::'+row['CURRENCY']})
        selected=[r for r in records if r.get('dataset_id')==flow]
        indexed={(r['geo_id'],r['year'],r['source_category']):r for r in selected}
        for country,year in sorted({(r['geo_id'],r['year'])for r in selected}):
            a,b= indexed.get((country,year,'CP04')),indexed.get((country,year,'CP045'))
            valid=a and b and a['value']is not None and b['value']is not None and a['value']>=b['value']
            source=a or b
            record={k:v for k,v in source.items()if k not in ['source_record','source_record_ref','native_value_text']}
            record.update(series_id=f'oecd::{flow}::CURRENT_MILLION_NAC::HOUSING_EX_HOME_ENERGY',
                          value=a['value']-b['value']if valid else None,source_category='HOUSING_EX_HOME_ENERGY',
                          derived_locally=True,eligible=bool(valid),source_id='derived:oecd:categories',
                          source_record_refs=(a['source_record_refs']if a else[])+(b['source_record_refs']if b else[]),
                          status='derived_current_price_difference'if valid else'missing_required_input',
                          status_label='Calculated housing excluding home energy'if valid else'Unavailable required source value',
                          inputs=[{'series_id':r['series_id'],'value':r['value'],'source_record_refs':r['source_record_refs']}for r in[a,b]if r])
            records.append(record)
        for category in LABELS:
            sid=f'derived::{flow}::SHARE_DOMESTIC_CONSUMPTION::{category}'
            series.append({'id':sid,'label':LABELS[category]+' share of domestic household consumption · '+classification,
                           'unit':'percent of domestic household consumption','dataset_id':flow,'classification':classification,
                           'source_category':category,'concept':'domestic_expenditure_share','source_ids':[source_id],
                           'definition':'Selected domestic purpose expenditure divided by same-country/year total domestic S14 household consumption, times 100.',
                           'adjustment':'Calculated ratio from original current-currency accounts; no currency/PPP conversion',
                           'sector':'S14','territorial_basis':'domestic','frequency':'annual','cross_country_eligible':True,
                           'interpretation':'A share of domestic household expenditure, not a share of resident disposable income or a household minimum-needs budget.'})
            for row in[r for r in records if r.get('dataset_id')==flow and r['source_category']==category and not r['series_id'].startswith('derived::')]:
                total=indexed.get((row['geo_id'],row['year'],'_T'));valid=row['value']is not None and total and total['value']is not None and total['value']>0
                record={k:v for k,v in row.items()if k not in ['source_record','source_record_ref','native_value_text','currency','unit_multiplier','native_unit_code']}
                record.update(series_id=sid,value=100*row['value']/total['value']if valid else None,
                              unit='percent of domestic household consumption',derived_locally=True,eligible=bool(valid),
                              source_id='derived:oecd:categories',status='derived_domestic_consumption_share',
                              status_label='Calculated share of domestic household expenditure',
                              source_record_refs=row['source_record_refs']+(total['source_record_refs']if total else[]),
                              inputs=[{'series_id':r['series_id'],'value':r['value'],'source_record_refs':r['source_record_refs'],'source_record':r.get('source_record')} for r in ([indexed.get((row['geo_id'],row['year'],'CP04')),indexed.get((row['geo_id'],row['year'],'CP045')),total] if category=='HOUSING_EX_HOME_ENERGY' else [row,total]) if r],
                              formula='100 × (CP04 − CP045) / TOTAL' if category=='HOUSING_EX_HOME_ENERGY' else '100 × category / TOTAL')
                records.append(record)
    for filename in ['oecd_table5a2018_structure.xml','oecd_nad_dataflows.xml']:
        path=ROOT/'sources'/filename;b=path.read_bytes();sources.append({'id':'oecd:categories:'+filename,'file':'sources/'+filename,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
            'url':'https://sdmx.oecd.org/public/rest/v1/dataflow/OECD.SDD.NAD/'+('DSD_NAMAIN10@DF_TABLE5A_T501/2.0?references=all'if'2018_structure'in filename else'all/latest?references=none')})
    module={'schema':'essentials-costs.oecd-categories-probe/v1','prepared_utc':datetime.now(timezone.utc).isoformat(),
            'countries':[{'id':id,'name':name}for id,name in COUNTRIES.items()], 'series':series,'records':records,'sources':sources,
            'coverage':{'native_core_records':510,'records':len(records),'series':len(series),
                        'native_countries':dict(Counter(r['geo_id']for r in records if not r['derived_locally'])),
                        'period':[2000,2025]},
            'limitations':['Bounded official four-country probe: Japan uses source COICOP2018; USA/Canada/UnitedKingdom use sourceCOICOP1999. They are not stitched across vintages.',
                           'Native current monetary amounts retain USD/CAD/GBP/JPY and unitmultiplier6; cross-currency levels are not compared as equal monetary units.',
                           'Domestic P31DC includes nonresident spending and excludes resident spending abroad; no direct subtraction from resident income is performed.',
                           'Selected purpose shares are calculated from the same-country/year domestic total, not income; health is not total healthcare-system expenditure.']}
    keys=[(r['series_id'],r['geo_id'],r['year'])for r in records]
    if len(keys)!=len(set(keys)):raise ValueError('Duplicate OECD keys')
    path=ROOT/'oecd_categories_probe.json';path.write_text(json.dumps(module,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')
    # Independent original-row and arithmetic checks against retained CSV objects.
    failures=[];native_checks=derived_checks=0
    by_key={(r['series_id'],r['geo_id'],r['year']):r for r in records}
    for row in records:
        if not row['derived_locally']:
            ref=row['source_record_ref'];original=raw_by_file[Path(ref['file']).name][ref['row_index']]
            good=original==row['source_record']and float(original['OBS_VALUE'])==row['value']and original['CURRENCY']==row['currency']and int(original['UNIT_MULT'])==6
            native_checks+=1
        else:
            values=[x['value']for x in row['inputs']]
            expected=(values[0]-values[1] if 'CURRENT_MILLION_NAC' in row['series_id'] else 100*(values[0]-values[1])/values[2] if row['source_category']=='HOUSING_EX_HOME_ENERGY' else 100*values[0]/values[1])
            source_values=[]
            for ref in row['source_record_refs']:
                source_values.append(float(raw_by_file[Path(ref['file']).name][ref['row_index']]['OBS_VALUE']))
            raw_expected=(source_values[0]-source_values[1] if 'CURRENT_MILLION_NAC' in row['series_id'] else 100*(source_values[0]-source_values[1])/source_values[2] if row['source_category']=='HOUSING_EX_HOME_ENERGY' else 100*source_values[0]/source_values[1])
            good=expected==row['value'] and raw_expected==row['value'];derived_checks+=1
        if not good:failures.append([row['series_id'],row['geo_id'],row['year']])
    result={'packet_bytes':path.stat().st_size,'packet_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'native_records_checked':native_checks,'derived_records_checked':derived_checks,'source_hashes':len(sources),'failures':failures,
            'coverage':module['coverage']}
    (ROOT/'qa/OECD_CATEGORIES_PROBE_READBACK.json').write_text(json.dumps(result,indent=2)+'\n')
    (ROOT/'OECD_CATEGORIES_SOURCE_INDEX.json').write_text(json.dumps(sources,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if failures:raise SystemExit(1)


if __name__=='__main__':run()
