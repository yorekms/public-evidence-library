"""Freeze official Eurostat COICOP household-purpose cells, without stitching vintages."""
from __future__ import annotations

from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
DATASETS = {'nama_10_cp18': 'COICOP 2018', 'nama_10_co3_p3': 'COICOP 1999'}
UNITS = ['CP_MEUR', 'CP_MNAC', 'PC_TOT', 'CP_EUR_HAB', 'CLV20_MEUR', 'CLV_I20']
CATEGORIES = ['TOTAL', 'CP01', 'CP04', 'CP045', 'CP06']
API = 'https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/'
FLAG_LABELS = {'b': 'break in time series', 'd': 'definition differs; see metadata',
               'e': 'estimated', 'p': 'provisional', 'f': 'forecast', 'n': 'not significant',
               's': 'Eurostat estimate', 'r': 'revised', 'u': 'low reliability',
               'c': 'confidential'}


def fetch(path: str, url: str):
    target = ROOT / path
    if not target.exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        with urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0'}), timeout=90) as response:
            raw = response.read()
        target.write_bytes(raw)
    raw = target.read_bytes()
    return {'id': 'eurostat:categories:' + target.stem, 'file': path, 'url': url,
            'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
            'retrieved_utc': datetime.fromtimestamp(target.stat().st_mtime, timezone.utc).isoformat()}


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def lookup(values, index):
    if isinstance(values, list):
        return values[index] if index < len(values) else None
    return values.get(str(index)) if values else None


def category_order(dim):
    index = dim['category']['index']
    return sorted(index, key=index.get) if isinstance(index, dict) else index


def source_ref(source, index, coordinates):
    return {'file': source['file'], 'flat_index': index, 'coordinates': coordinates,
            'value_pointer': '/value/' + str(index), 'missing_value_pointer_may_be_absent': True,
            'status_pointer': '/status/' + str(index)}


def run():
    work = []
    for dataset in DATASETS:
        dimension = 'coicop18' if dataset.endswith('cp18') else 'coicop'
        for unit in UNITS:
            params = [('lang', 'EN'), ('freq', 'A'), ('unit', unit),
                      *[(dimension, code) for code in CATEGORIES],
                      ('sinceTimePeriod', '2000'), ('untilTimePeriod', '2025')]
            work.append((f'sources/categories_{dataset}_{unit}.json', API + dataset + '?' + urlencode(params)))
    work.extend([
        ('sources/categories_cp18_metadata.html', 'https://ec.europa.eu/eurostat/cache/metadata/en/nama_10_cp18_esms.htm'),
        ('sources/categories_legacy_metadata.html', 'https://ec.europa.eu/eurostat/cache/metadata/en/nama10_esms.htm'),
        ('sources/categories_wdi_country_lookup.json', 'https://api.worldbank.org/v2/country?format=json&per_page=400'),
    ])
    sources = []
    with ThreadPoolExecutor(max_workers=4) as pool:
        jobs = {pool.submit(fetch, path, url): path for path, url in work}
        for future in as_completed(jobs):
            source = future.result()
            sources.append(source)
            print('Retained', source['file'], source['bytes'], flush=True)
    sources.sort(key=lambda s: s['file'])
    source_by_file = {s['file']: s for s in sources}
    countries_raw = json.loads((ROOT/'sources/categories_wdi_country_lookup.json').read_bytes())[1]
    iso = {c['iso2Code']: c['id'] for c in countries_raw if c['region']['id'] != 'NA'}
    iso.update({'EL': 'GRC', 'UK': 'GBR', 'XK': 'XKX'})
    series, records, countries, exclusions, source_headers = [], [], {}, [], {}
    for dataset, classification in DATASETS.items():
        cdim = 'coicop18' if dataset.endswith('cp18') else 'coicop'
        for unit in UNITS:
            source = source_by_file[f'sources/categories_{dataset}_{unit}.json']
            raw = json.loads((ROOT/source['file']).read_bytes())
            if raw.get('error'):
                raise ValueError(raw['error'])
            dims = raw['id']
            labels = {dim: raw['dimension'][dim]['category'].get('label', {}) for dim in dims}
            orders = {dim: category_order(raw['dimension'][dim]) for dim in dims}
            source_headers[source['id']] = {k: raw.get(k) for k in ['label', 'updated', 'id', 'size', 'extension']}
            for code in orders[cdim]:
                series_id = f'eurostat::{dataset}::{unit}::{code}'
                current = unit.startswith('CP_')
                label = labels[cdim].get(code, code)
                series.append({'id': series_id, 'label': label + ' · ' + classification + ' · ' + labels['unit'][unit],
                               'unit': labels['unit'][unit], 'native_unit_code': unit,
                               'concept': {'TOTAL': 'household_consumption_total', 'CP01': 'food', 'CP04': 'housing_including_energy', 'CP045': 'home_energy', 'CP06': 'healthcare'}[code],
                               'source_category': code, 'classification': classification, 'dataset_id': dataset,
                               'sector': 'S14', 'territorial_basis': 'domestic',
                               'definition': label + '; household final consumption on the domestic territory, including nonresident spending and excluding resident spending abroad.',
                               'adjustment': 'Original Eurostat compiled source value', 'source_ids': [source['id']],
                               'source_url': 'https://ec.europa.eu/eurostat/databrowser/view/' + dataset + '/default/table?lang=en',
                               'frequency': 'annual', 'cross_country_eligible': unit == 'PC_TOT',
                               'temporal_eligible': True, 'current_price_additive': current or unit == 'PC_TOT',
                               'estimate_note': 'Compiled national-account statistics; original provisional, estimated, break and definition flags retained. No local missing-year filling.',
                               'interpretation': ('Share of domestic household consumption; it is not a share of resident disposable income.' if unit == 'PC_TOT' else
                                                  'Source chain-linked volume/index history; components must not be subtracted or added outside the valid reference-price basis.' if unit.startswith('CLV') else
                                                  'Domestic household expenditure account, not a median household cash bill or a resident-sector income subtraction.')})
            sizes = raw['size']
            for index, positions in enumerate(itertools.product(*(orders[d] for d in dims))):
                coord = dict(zip(dims, positions))
                geo = coord['geo']
                value = lookup(raw.get('value'), index)
                flag = lookup(raw.get('status'), index) or ''
                if geo not in iso:
                    exclusions.append({'source_id': source['id'], 'geo_code': geo, 'geo_name': labels['geo'].get(geo, geo),
                                       'reason': 'aggregate_or_unmapped_geography_retained_in_raw_source', 'cells': 1})
                    continue
                country = iso[geo]
                countries[country] = labels['geo'].get(geo, geo)
                record = {'series_id': f'eurostat::{dataset}::{unit}::{coord[cdim]}', 'geo_id': country,
                          'geo_name': countries[country], 'native_geo_code': geo, 'year': int(coord['time']),
                          'value': value, 'unit': labels['unit'][unit], 'native_unit_code': unit,
                          'status': 'source_missing' if not finite(value) else 'published_national_account_estimate',
                          'status_label': 'Unavailable in source' if not finite(value) else 'Published domestic household-consumption estimate',
                          'native_obs_status': flag,
                          'native_obs_status_labels': [FLAG_LABELS.get(char, 'native flag ' + char) for char in flag if char not in ' ,'],
                          'source_id': source['id'], 'source_record_ref': source_ref(source, index, coord),
                          'source_record_refs': [source_ref(source, index, coord)],
                          'eligible': finite(value), 'derived_locally': False, 'estimate': True,
                          'classification': classification, 'source_category': coord[cdim],
                          'sector': 'S14', 'territorial_basis': 'domestic',
                          'comparability_group': f'{dataset}::{country}::{unit}',
                          'currency': 'EUR' if unit in ['CP_MEUR', 'CP_EUR_HAB', 'CLV20_MEUR'] else None}
                records.append(record)
    native = list(records)
    index = {(r['classification'], r['geo_id'], r['year'], r['native_unit_code'], r['source_category']): r for r in native}
    for dataset, classification in DATASETS.items():
        for unit in ['CP_MEUR', 'CP_MNAC', 'PC_TOT', 'CP_EUR_HAB']:
            source_series = next(s for s in series if s['dataset_id'] == dataset and s['native_unit_code'] == unit)
            sid = f'derived::{dataset}::{unit}::HOUSING_EX_HOME_ENERGY'
            series.append({**source_series, 'id': sid, 'label': 'Housing and water excluding home energy · ' + classification + ' · ' + source_series['unit'],
                           'concept': 'housing_excluding_home_energy', 'source_category': 'CP04_MINUS_CP045',
                           'definition': 'Domestic housing, rentals, water and dwelling services (CP04) less electricity, gas and other fuels (CP045). Includes imputed owner-occupied rent; excludes home-energy duplication.',
                           'adjustment': 'Calculated from original current-price or same-total-share values: CP04 − CP045',
                           'source_ids': [s['source_ids'][0] for s in series if s.get('dataset_id') == dataset and s.get('native_unit_code') == unit and s.get('source_category') in ['CP04','CP045']]})
            for key, housing in [(key, r) for key, r in index.items() if key[0] == classification and key[3] == unit and key[4] == 'CP04']:
                energy = index.get((*key[:4], 'CP045'))
                valid = finite(housing.get('value')) and energy and finite(energy.get('value')) and housing['value'] >= energy['value']
                value = housing['value'] - energy['value'] if valid else None
                refs = housing['source_record_refs'] + (energy['source_record_refs'] if energy else [])
                records.append({'series_id': sid, 'geo_id': housing['geo_id'], 'geo_name': housing['geo_name'],
                                'native_geo_code': housing['native_geo_code'], 'year': housing['year'], 'value': value,
                                'unit': housing['unit'], 'native_unit_code': unit, 'status': 'derived_current_price_difference' if valid else 'missing_or_invalid_required_input',
                                'status_label': 'Calculated housing excluding home energy' if valid else 'Unavailable: required inputs missing or inconsistent',
                                'native_obs_status': '', 'source_id': 'derived:eurostat:categories',
                                'source_record_refs': refs, 'eligible': bool(valid), 'derived_locally': True, 'estimate': True,
                                'classification': classification, 'source_category': 'CP04_MINUS_CP045',
                                'sector': 'S14', 'territorial_basis': 'domestic', 'currency': housing['currency'],
                                'formula': 'CP04 − CP045; same dataset, country, year and additive current-price/share unit',
                                'inputs': [{k: r[k] for k in ['series_id','value','source_record_refs','native_obs_status','native_obs_status_labels']} for r in [housing, energy] if r],
                                'comparability_group': f'{dataset}::{housing["geo_id"]}::{unit}'})
    counts = {}
    for s in series:
        rows = [r for r in records if r['series_id'] == s['id']]
        values = [r for r in rows if finite(r.get('value'))]
        counts[s['id']] = {'rows': len(rows), 'numerical_values': len(values), 'economies': len({r['geo_id'] for r in values}),
                            'first_numeric_year': min((r['year'] for r in values), default=None), 'last_numeric_year': max((r['year'] for r in values), default=None)}
    keys = [(r['series_id'],r['geo_id'],r['year']) for r in records]
    if len(keys) != len(set(keys)):
        raise ValueError('Duplicate native category coordinates')
    module = {'schema': 'essentials-costs.categories-source-module/v1',
              'prepared_utc': datetime.now(timezone.utc).isoformat(), 'period': [2000,2025],
              'countries': [{'id': key,'name': name} for key,name in sorted(countries.items())],
              'series': series, 'records': records, 'sources': sources, 'source_headers': source_headers,
              'coverage': {'series': len(series), 'records': len(records), 'native_records': len(native),
                           'derived_records': len(records)-len(native), 'numerical_values': sum(finite(r.get('value')) for r in records),
                           'countries': len(countries), 'by_series': counts},
              'limitations': ['COICOP expenditure is domestic S14 consumption. It cannot be directly subtracted from resident S14 income without a stated bridge/allocation model.',
                              'Housing CP04 already contains home energy CP045. Housing excluding energy uses CP04 minus CP045 only in additive current-price/share units; chain-linked volume differences are not computed.',
                              'COICOP 1999 and 2018 remain separate datasets and are not stitched or silently substituted. Migrated countries can have missing legacy rows and short current-classification histories.',
                              'Health is household final consumption of health products/services, excluding government social transfers in kind; it is not total health-system spending.',
                              'Household expenditure includes national-account imputations such as owner-occupied rent; an average expenditure account is not a median household cash bill or minimum-needs budget.',
                              'Current euro values retain exchange-rate and price effects; chain-linked volumes and domestic shares have different meanings.'],
              'excluded_geographies': dict(Counter((r['geo_code'] for r in exclusions))), 'native_flag_legend': FLAG_LABELS}
    (ROOT/'categories_module.json').write_text(json.dumps(module,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n')
    (ROOT/'CATEGORIES_SOURCE_INDEX.json').write_text(json.dumps({'sources':sources,'source_headers':source_headers},ensure_ascii=False,indent=2)+'\n')
    (ROOT/'CATEGORIES_COVERAGE.json').write_text(json.dumps(module['coverage'],ensure_ascii=False,indent=2)+'\n')
    with (ROOT/'categories_values.csv').open('w',newline='') as f:
        keys = ['series_id','geo_id','geo_name','native_geo_code','year','value','unit','native_unit_code','status','native_obs_status','classification','source_category','sector','territorial_basis','derived_locally','source_id','source_record_refs']
        writer = csv.DictWriter(f,fieldnames=keys);writer.writeheader()
        for r in records:writer.writerow({k: json.dumps(r[k],ensure_ascii=False) if isinstance(r.get(k),(list,dict)) else r.get(k) for k in keys})
    lines=['sha256\tbytes\tpath']
    for source in sources:lines.append(f'{source["sha256"]}\t{source["bytes"]}\t{source["file"]}')
    (ROOT/'CATEGORIES_SHA256SUMS.tsv').write_text('\n'.join(lines)+'\n')
    print(json.dumps(module['coverage'],indent=2),flush=True)


if __name__ == '__main__':
    run()
