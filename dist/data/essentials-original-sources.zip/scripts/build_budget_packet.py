"""Curate source-aligned current-price input ledgers; never overwrite originals."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[1]
UNIT = 'current million EUR'


def finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def compact(original, scope):
    if original is None:
        return None
    code = original.get('native_unit_code', original.get('unit_code'))
    if code != 'CP_MEUR':
        raise ValueError('Only additive current-price million-EUR inputs enter this ledger.')
    keys = ['value', 'sector', 'geo_id', 'geo_name', 'year', 'source_id', 'source_record_ref',
            'native_obs_status', 'native_obs_status_labels', 'status', 'status_label',
            'classification', 'na_item', 'direct', 'currency', 'eligible', 'estimate',
            'native_geo', 'native_geo_code', 'comparability_group', 'source_category']
    result = {k: copy.deepcopy(original[k]) for k in keys if k in original}
    result.update(unit=UNIT, native_unit_code=code, native_unit_label=original['unit'],
                  territorial_basis=scope, source_series_id=original['series_id'])
    return result


def build():
    category_path = ROOT / 'categories_module.json'
    income_path = ROOT / 'income_alignment/income_module.json'
    c = json.loads(category_path.read_text())
    i = json.loads(income_path.read_text())
    cindex, iindex = {}, {}
    for data, index in [(c, cindex), (i, iindex)]:
        for r in data['records']:
            key = (r['series_id'], r['geo_id'], r['year'])
            if key in index:
                raise ValueError('Duplicate native source keys must not be selected silently.')
            index[key] = r
    countries = {}
    for data in (c, i):
        for country in data['countries']:
            countries.setdefault(country['id'], country['name'])
    inputs = {
        'income_gross': ('eurostat::nasa_10_nf_tr::S14:B6G:RECV:CP_MEUR', 'resident'),
        'income_net': ('eurostat::nasa_10_nf_tr::S14:B6N:RECV:CP_MEUR', 'resident'),
        'resident_consumption': ('eurostat::nasa_10_nf_tr::S14:P3:PAID:CP_MEUR', 'resident'),
        'bridge_domestic': ('eurostat::nama_10_fcs::CP_MEUR::P31_S14_DC', 'domestic'),
        'bridge_national': ('eurostat::nama_10_fcs::CP_MEUR::P31_S14_NC', 'resident'),
        'resident_abroad': ('eurostat::nama_10_fcs::CP_MEUR::P33', 'resident'),
        'nonresident_domestic': ('eurostat::nama_10_fcs::CP_MEUR::P34', 'domestic'),
    }
    categories = {'domestic_total': 'TOTAL', 'food': 'CP01',
                  'housing_including_energy': 'CP04', 'energy': 'CP045', 'healthcare': 'CP06'}
    rows = []
    editions = [('nama_10_cp18', 'COICOP 2018'), ('nama_10_co3_p3', 'COICOP 1999')]
    for geo, name in sorted(countries.items()):
        for year in range(2000, 2026):
            for dataset, edition in editions:
                cells = {key: compact(cindex.get((f'eurostat::{dataset}::CP_MEUR::{code}', geo, year)), 'domestic')
                         for key, code in categories.items()}
                cells.update({key: compact(iindex.get((series_id, geo, year)), scope)
                              for key, (series_id, scope) in inputs.items()})
                if not any(v is not None for v in cells.values()):
                    continue
                rows.append({'geo_id': geo, 'geo_name': name, 'year': year,
                             'classification': edition, 'unit': UNIT, 'inputs': cells})
    sources = [copy.deepcopy(s) for s in c['sources'] + i['sources']]
    coverage = {'countries': len(countries), 'ledger_rows': len(rows),
                'classifications': [name for _, name in editions],
                'original_numerical_input_cells_within_ledgers': sum(finite(v.get('value')) for row in rows for v in row['inputs'].values() if v is not None),
                'source_income_years': i['coverage'], 'source_category_coverage': c['coverage']}
    limitations = [
        'The remainder is an analyst allocation estimate for national household accounts, not observed median household cash left over, a complete minimum-needs budget or a saving rate.',
        'Domestic category consumption includes nonresident purchases here and excludes residents’ purchases abroad. The central estimate assumes residents have the domestic category spending mix, applied to published resident household consumption.',
        'Income and consumption use the household-only S14 sector. NPISH/S15 and combined-sector income are not substituted.',
        'Gross disposable income is after direct taxes and transfers but before consumption of fixed capital; net income uses the source B6N series. Neither is the earlier equivalised median-income measure.',
        'Food includes food and non-alcoholic goods; restaurant services are outside CP01. Home energy covers electricity, gas and other home fuels, not motor fuels.',
        'Housing includes imputed owner-occupied rent and other housing services; dwelling purchases and mortgage principal are outside these consumption categories. Housing excluding energy is CP04 minus CP045, so home energy is counted once.',
        'Household-consumption healthcare and separately sourced global out-of-pocket healthcare are different concepts. Global OOP values are not added to the CP06 component.',
        'Only current-price inputs are added or subtracted. Chain-linked volume categories are not additive and remain outside the remainder calculation.',
        'COICOP 2018 and COICOP 1999 are separate source classifications. Missing countries, years and components are not interpolated, carried forward or stitched across editions.',
        'The allocation range is conditional on coherent published cross-border expenditure totals. It describes unknown category allocation of those flows, not a statistical confidence interval or all source uncertainty.',
        'Published source accounts can have different revision vintages. Original flags and source-coherence differences remain visible; identities are never forced to balance.',
        'Comparisons of remaining shares use the same definition and income basis. Original nominal monetary totals remain current million EUR; no household PPP or industry inflation factor is applied.',
        'No industry demand scenario is automatically translated into household income, prices, welfare or a future budget.',
    ]
    packet = {'schema': 'essentials-costs.budget-data/v1',
              'prepared_utc': datetime.now(timezone.utc).isoformat(), 'period': [2000, 2025],
              'unit': UNIT, 'classifications': [name for _, name in editions],
              'countries': [{'id': k, 'name': v} for k, v in sorted(countries.items(), key=lambda pair: pair[1])],
              'rows': rows, 'sources': sources, 'limitations': limitations, 'coverage': coverage,
              'methods': {'formula': 'Resident S14 consumption × selected domestic category expenditure / domestic total consumption; remainder = matched S14 disposable income minus this allocated amount.',
                          'categories': {'food': 'CP01', 'housing': 'CP04 − CP045', 'energy': 'CP045', 'healthcare': 'CP06'},
                          'price_basis': 'current million EUR, same-country and source year',
                          'classification_stitching': False,
                          'bridge_absolute_tolerance_current_million_EUR': 1e-8,
                          'source_modules': [{'file': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in [category_path, income_path]]}}
    raw = (json.dumps(packet, ensure_ascii=False, separators=(',', ':'), allow_nan=False)+'\n').encode()
    (ROOT/'budget.json').write_bytes(raw)
    manifest = {'schema': packet['schema'], 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                'ledger_rows': len(rows), 'countries': len(countries), 'period': [2000, 2025]}
    (ROOT/'BUDGET_MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    build()
