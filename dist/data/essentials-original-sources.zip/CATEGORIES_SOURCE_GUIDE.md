# Housing, food, home energy and health consumption accounts

The category source module is `categories_module.json`. It retains 2000–2025 source years, with actual availability varying by country, classification, category and unit. All missing cells and native observation flags remain available. Country identifiers use ISO3-compatible IDs alongside original Eurostat geography codes; EU/euro-area aggregates remain in the raw files.

## Source definitions

Eurostat's current dataset `nama_10_cp18` uses COICOP 2018. The separate legacy dataset `nama_10_co3_p3` uses COICOP 1999. They are retained separately and are not stitched into one series. A common dissemination update date does not make their historical national-account revisions interchangeable.

These are household-sector (S14) **domestic** consumption accounts: expenditure by nonresidents inside the country is included, while residents' spending abroad is excluded. This differs from resident-sector disposable income. A matching country and year alone therefore does not justify direct subtraction from resident income.

The categories retained are total household consumption (`TOTAL`), food/non-alcoholic beverages (`CP01`), housing/water/home energy (`CP04`), electricity/gas/other fuels (`CP045`) and health (`CP06`). Housing includes owner-occupied imputed rent. Food excludes restaurant/catering services. Home energy excludes motor fuel. Health excludes social transfers in kind and is not total health-system spending or necessarily identical to an out-of-pocket medical-bill measure.

Primary methods: [current COICOP metadata](https://ec.europa.eu/eurostat/cache/metadata/en/nama_10_cp18_esms.htm), [annual national-account metadata](https://ec.europa.eu/eurostat/cache/metadata/en/nama10_esms.htm), [current data table](https://ec.europa.eu/eurostat/databrowser/view/nama_10_cp18/default/table?lang=en), and [legacy table](https://ec.europa.eu/eurostat/databrowser/view/nama_10_co3_p3/default/table?lang=en).

## Original units and labeled derivation

Six native unit families are retained for each classification: current million euro (`CP_MEUR`), current million national-currency units (`CP_MNAC`), percentage of domestic consumption (`PC_TOT`), current euro per capita (`CP_EUR_HAB`), chain-linked 2020 million euro (`CLV20_MEUR`) and chain-linked index 2020=100 (`CLV_I20`). Native current euro values retain price and exchange-rate effects. Country-specific national currencies are not equal international units.

Housing excluding home energy is explicitly calculated as `CP04 − CP045`, only when both inputs are available and compatible within the same dataset, country, year and current-price/share unit. Both source inputs and references are retained. Housing/energy overlap is never counted twice. Chain-linked components are nonadditive, so no chain-linked subtraction is produced. Missing or inconsistent inputs produce an unavailable derivative.

National-account expenditure is a compiled estimate, and housing imputations are included. Original flags distinguish provisional values, breaks, definition differences and other source statuses where supplied. Empty flags do not certify direct measurement. No values are interpolated, carried forward or inferred locally.

## Research use and provenance

For a resident allocation estimate, analysts may explicitly multiply each domestic category share by resident S14 final consumption. Such a proportional allocation is an assumption, not an observed resident category amount. Any residual must identify the selected categories, income concept, domestic/resident scope, imputed housing treatment, unit, price basis and allocation model. It is not a median household cash budget or a minimum-needs standard.

`CATEGORIES_SOURCE_INDEX.json` stores retrieval URLs, exact raw byte hashes and JSON-stat source headers. Every native row retains its original cube coordinates, flat index, status and source file. The acquisition script is `scripts/acquire_categories.py`; `qa/independent_categories_readback.py` recomputes cube positions and housing differences independently. Existing source collections and applications were not changed.
