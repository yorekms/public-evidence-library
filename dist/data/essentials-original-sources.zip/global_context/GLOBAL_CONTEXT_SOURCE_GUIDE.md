# Global healthcare and healthy-diet cost context

This source module supplies six published measures for exploring essential-cost pressures. It is separate from a matched household income-minus-expense calculation. No source value is converted, deflated, interpolated or subtracted from another dataset locally.

## Healthcare paid directly by households

Three annual WHO Global Health Expenditure Database series are retained through the World Bank WDI API, with source data for 2000–2024 and requested 2025 missing cells kept unavailable:

- `wdi::SH.XPD.OOPC.PC.CD`: average out-of-pocket health expenditure per person per year in current U.S. dollars.
- `wdi::SH.XPD.OOPC.PP.CD`: the publisher's average out-of-pocket health expenditure per person per year in current PPP international dollars.
- `wdi::SH.XPD.OOPC.CH.ZS`: out-of-pocket payments as a percentage of total current health expenditure. The denominator is healthcare expenditure, not household income or total household consumption.

Each healthcare series has numerical values for 193 nonaggregate economies. Country-year coverage varies. Original WHO/WDI native flags, footnotes, year, units and complete API records are preserved. The WDI source vintage is retained from the native data header; the source organization identifies WHO GHED updated 12 December 2025. A blank native observation flag does not certify direct measurement.

These averages do not describe a typical patient's bill. Different levels can reflect healthcare prices, use, disease burden, insurance and public financing. Current-dollar and current-PPP histories retain price changes over time. They are not constant-2021 household welfare amounts and cannot be subtracted from constant-2021 PIP income without a separately justified conversion and compatible population basis.

Official definitions: [WHO/WDI out-of-pocket health spending per person, current USD](https://data.worldbank.org/indicator/SH.XPD.OOPC.PC.CD), [current PPP international dollars](https://data.worldbank.org/indicator/SH.XPD.OOPC.PP.CD), and [share of current health expenditure](https://databank.worldbank.org/metadataglossary/world-development-indicators/series/SH.XPD.OOPC.CH.ZS).

## Least-cost healthy diets

The World Bank Food Prices for Nutrition source 88, classification **FPN 5.0**, updated **21 July 2026**, provides actual published annual records for 2017–2025. Three series are retained:

- `fpn::CoHD_PPP`: the modeled daily least-cost healthy diet in year-specific PPP international dollars, with 1,495 numerical values across 167 economies.
- `fpn::CoHD_LCU`: the original modeled daily cost in national currency, with 1,558 numerical values across 174 economies. Different national currencies are not ranked as equal units.
- `fpn::CoHD_headcount`: the publisher's modeled percentage unable to afford a healthy diet, with 1,314 numerical values across 146 economies.

All 176 nonaggregate source economies and their nine source years are retained for each food series, including missing cells. The raw responses also retain sixteen regional/income aggregates excluded from the normalized country table; the exclusion ledger identifies them. Coverage reported by the normalized packet is calculated from its actual frozen cells, and may differ from a catalogue headline describing another reporting subset.

The food-cost benchmark uses the least expensive locally available foods meeting a representative healthy-diet basket of 2,330 kcal/day. It describes an estimated least-cost standard, not what households actually spend, a complete family food bill, food preferences or a personal nutrition prescription. The reference basket covers six food groups. Native metadata identifies Bahamas, Guyana, Haiti, Iran, Myanmar and Sint Maarten as using 2017 ICP food prices because 2021 prices were unavailable.

The archived FAO July 2025 method brief explains how 2021 ICP local-currency benchmark costs are updated using national food CPI ratios in nonbenchmark years, then divided by the **year-specific** private-consumption PPP. PPP values may be imputed or extrapolated by the source. Consequently these annual values are modeled source estimates in current PPP, not a new survey of every food item each year and not constant-2021 purchasing power. No additional local food-CPI or PPP calculation is applied.

The affordability estimates compare a diet cost with income available after an allowance for basic non-food needs. They already incorporate a source model and assumptions about non-food needs and income distributions. They are not a local four-category residual budget. In source precision, a zero prevalence may represent a positive number rounded down. Source edition 5.0's native 2026 metadata identifies updated poverty thresholds in 2021 PPP; the archived 2025 method brief uses earlier thresholds and is preserved as a dated method document, not the authority for the current threshold values.

The native `CoHD_headcount` API long definition mentions an “energy sufficient” diet despite its healthy-diet indicator title. This source wording inconsistency is preserved in `native_metadata`; the indicator code, title and primary programme methods identify healthy-diet affordability. The normalized series exposes a note about this discrepancy rather than silently rewriting the source metadata.

Official methods: [Food Prices for Nutrition programme and current methods](https://www.worldbank.org/en/programs/icp/brief/foodpricesfornutrition), [FAO July 2025 method brief](https://files-faostat.fao.org/production/CAHD/Methods_Brief_FAOSTAT_CoAHD_indicators.pdf), and the archived source-specific metadata responses. Generic `/country/all/indicator/CoHD_PPP` requests do not retrieve source 88 data; the working source-specific endpoint is recorded in SOURCE_INDEX.json.

## Reproduction, missingness and source preservation

`global_context_module.json` contains the six definitions, complete original records, precise source-row references, countries, source register, coverage and limitations. `global_context_values.csv` provides the main original numerical fields. All source bytes are in `raw/`; `SOURCE_INDEX.json` records their retrieval URLs, SHA-256 hashes and native response metadata. `EXCLUSION_LEDGER.json` records excluded aggregate rows. The acquisition and independent-readback scripts are in `scripts/`.

Two optional per-person DataBank glossary URLs returned a DataBank Error Page with HTTP 200. Those responses are retained for audit and explicitly marked unusable as metadata. The corresponding indicator API metadata and original data responses are valid and supply the definitions and native values; the healthcare share glossary is also available. No content from the error pages is used as statistical evidence.

`INDEPENDENT_READBACK.json` checks archived source hashes and every normalized native value, geography, year and complete source record without importing the acquisition script. The module does not change any pre-existing workbench collection, source archive, model coefficient, application code, server or deployment.
