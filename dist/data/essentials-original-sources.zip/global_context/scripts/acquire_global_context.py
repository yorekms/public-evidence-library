"""Freeze official global healthcare and diet-cost context; no budget residual."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import requests, json, hashlib, csv, math

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'raw'
RAW.mkdir(parents=True, exist_ok=True)

DEFINITIONS = {
 'SH.XPD.OOPC.PC.CD': {
  'id':'wdi::SH.XPD.OOPC.PC.CD','label':'Out-of-pocket healthcare spending per person, current USD',
  'unit':'current USD per person per year','concept':'healthcare','price_basis':'current USD; original published value',
  'interpretation':'Average health spending paid directly out of pocket by households, divided by population. Excludes prepaid insurance premiums and government financing; not a typical patient bill or total healthcare spending.',
  'cross_country_eligible':True,'temporal_eligible':True},
 'SH.XPD.OOPC.PP.CD': {
  'id':'wdi::SH.XPD.OOPC.PP.CD','label':'Out-of-pocket healthcare spending per person, current PPP',
  'unit':'current international dollars per person per year','concept':'healthcare','price_basis':'current PPP international dollars; original published source adjustment',
  'interpretation':'Published WHO/WDI average household out-of-pocket health spending per person at current PPP. This is not constant-2021 purchasing power and is not subtracted from PIP constant-2021 income.',
  'cross_country_eligible':True,'temporal_eligible':True},
 'SH.XPD.OOPC.CH.ZS': {
  'id':'wdi::SH.XPD.OOPC.CH.ZS','label':'Out-of-pocket share of current healthcare spending',
  'unit':'percent of current health expenditure','concept':'healthcare','price_basis':'share of current health expenditure',
  'interpretation':'Share of the country’s total current health expenditure paid out of pocket by households. Its denominator is healthcare spending, not household income or household consumption.',
  'cross_country_eligible':True,'temporal_eligible':True},
 'CoHD_PPP': {
  'id':'fpn::CoHD_PPP','label':'Least-cost healthy diet per person per day, PPP',
  'unit':'current PPP international dollars per representative person per day','concept':'food','price_basis':'source year-specific private-consumption PPP; 2021 ICP benchmark food prices updated using national food CPI',
  'interpretation':'Published FAO/World Bank estimate of the least expensive locally available foods meeting the healthy-diet basket at 2,330 kcal/day. It is a modeled benchmark, not actual household food expenditure or a universal individual dietary prescription.',
  'cross_country_eligible':True,'temporal_eligible':True},
 'CoHD_LCU': {
  'id':'fpn::CoHD_LCU','label':'Least-cost healthy diet per person per day, national currency',
  'unit':'current local currency per representative person per day','concept':'food','price_basis':'current national currency; source 2021 food-basket cost updated using food CPI in other years',
  'interpretation':'Original national-currency daily healthy-diet benchmark cost. Different national currency units are not ranked as equal spending units across countries.',
  'cross_country_eligible':False,'temporal_eligible':True},
 'CoHD_headcount': {
  'id':'fpn::CoHD_headcount','label':'Population unable to afford a healthy diet, published estimate',
  'unit':'percent of population','concept':'food','price_basis':'source modeled affordability using food costs, income distributions and basic non-food allowances',
  'interpretation':'Published modeled prevalence, accounting for an allowance for basic non-food needs. Zero may mean a positive estimate rounded down at source precision. This is not a locally calculated residual household budget.',
  'cross_country_eligible':True,'temporal_eligible':True},
}


def finite(v):
 return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)


def main():
 tasks = [('wdi_countries.json','https://api.worldbank.org/v2/country',{'format':'json','per_page':400}),
          ('wdi_source_2.json','https://api.worldbank.org/v2/sources/2',{'format':'json'}),
          ('fpn_source_88.json','https://api.worldbank.org/v2/sources/88',{'format':'json'}),
          ('fpn_indicator_catalogue.json','https://api.worldbank.org/v2/sources/88/indicators',{'format':'json','per_page':500}),
          ('fpn_programme.html','https://www.worldbank.org/en/programs/icp/brief/foodpricesfornutrition',{}),
          ('fao_methods_2025.pdf','https://files-faostat.fao.org/production/CAHD/Methods_Brief_FAOSTAT_CoAHD_indicators.pdf',{})]
 for code in DEFINITIONS:
  if code.startswith('SH.'):
   tasks.extend([(f'wdi_data_{code}.json',f'https://api.worldbank.org/v2/country/all/indicator/{code}',{'format':'json','per_page':20000,'date':'2000:2025','footnote':'y'}),
                 (f'wdi_metadata_{code}.json',f'https://api.worldbank.org/v2/indicator/{code}',{'format':'json'}),
                 (f'wdi_glossary_{code}.html',f'https://databank.worldbank.org/metadataglossary/world-development-indicators/series/{code}',{})])
  else:
   tasks.extend([(f'fpn_data_{code}.json',f'https://api.worldbank.org/v2/sources/88/country/all/series/{code}/time/all',{'format':'json','per_page':20000}),
                 (f'fpn_metadata_{code}.json',f'https://api.worldbank.org/v2/sources/88/series/{code}/metadata',{'format':'json','per_page':20000})])
 def fetch(task):
  name,url,params=task
  response=requests.get(url,params=params,timeout=60,headers={'User-Agent':'Mozilla/5.0 Public-data-research'})
  response.raise_for_status()
  raw=response.content;(RAW/name).write_bytes(raw)
  out={'id':'global:'+name,'file':'raw/'+name,'url':response.url,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'retrieved_utc':datetime.now(timezone.utc).isoformat(),'content_type':response.headers.get('Content-Type'),'license':'CC BY 4.0 for World Bank data; source publication terms retained for methodology documents'}
  if name.endswith('.html') and b'DataBank Error Page' in raw:
   out.update(usable_for_metadata=False,retrieval_note='The server returned a DataBank Error Page with HTTP 200. Retained for audit only; not used as indicator metadata. Indicator API metadata is available separately.')
  return out
 with ThreadPoolExecutor(max_workers=4) as pool: sources=list(pool.map(fetch,tasks))
 def read(name):return json.loads((RAW/name).read_text())
 countries=read('wdi_countries.json')[1];known={c['id']:c['name'] for c in countries if c['region']['id']!='NA'}
 records=[];series=[];exclusions=[];counts={}
 for code,definition in DEFINITIONS.items():
  s=dict(definition)
  s.update(frequency='annual, available published source years',residual_eligible=False,
           adjustment='Published source value; no local conversion, interpolation or inflation adjustment',
           estimate_note='Published compiled or modeled estimate; blank source status does not certify direct measurement.',
           source_ids=['global:'+('wdi_data_' if code.startswith('SH.') else 'fpn_data_')+code+'.json'])
  if code.startswith('SH.'):
   file='wdi_data_'+code+'.json';raw=read(file);metadata=read('wdi_metadata_'+code+'.json')[1][0]
   if not isinstance(raw,list)or len(raw)!=2 or int(raw[0]['pages'])!=1:raise ValueError('Incomplete healthcare response')
   s.update(definition=metadata['sourceNote'],native_metadata=metadata,source_vintage=raw[0]['lastupdated'],source_url='https://data.worldbank.org/indicator/'+code)
   for idx,row in enumerate(raw[1]):
    geo=row.get('countryiso3code')
    if geo not in known:
     exclusions.append({'source_file':'raw/'+file,'row_index':idx,'reason':'Not in native nonaggregate World Bank country list','geo_id':geo});continue
    records.append({'series_id':s['id'],'geo_id':geo,'geo_name':known[geo],'year':int(row['date']),'source_year':int(row['date']),
                    'value':row['value'],'unit':s['unit'],'status':'published_health_account_estimate' if finite(row['value']) else 'source_missing',
                    'status_label':'Published WHO/WDI health-account estimate' if finite(row['value']) else 'Unavailable in source',
                    'estimate':True,'derived_locally':False,'source_adjusted':'PPP' in s['price_basis'],'eligible':finite(row['value']),
                    'source_id':'global:'+file,'native_obs_status':row.get('obs_status',''),'native_footnote':row.get('footnote',''),
                    'source_record_ref':'raw/'+file+'#/1/'+str(idx),'source_record_refs':['raw/'+file+'#/1/'+str(idx)],'source_record':row,
                    'residual_eligible':False})
  else:
   file='fpn_data_'+code+'.json';raw=read(file);metadata=read('fpn_metadata_'+code+'.json')
   if int(raw['pages'])!=1:raise ValueError('Incomplete food response')
   native_meta=metadata['source'][0]['concept'][0]['variable'][0]['metatype']
   meta={m['id']:m['value']for m in native_meta}
   s.update(definition=meta.get('Longdefinition',''),native_metadata=metadata,source_vintage=raw['lastupdated'],source_url='https://www.worldbank.org/en/programs/icp/brief/foodpricesfornutrition')
   if code=='CoHD_headcount':
    s['estimate_note']+=' Native API long-definition text mentions an energy-sufficient diet under the healthy-diet indicator title; the source programme methods distinguish diet standards. This wording discrepancy is preserved and documented.'
   for idx,row in enumerate(raw['source']['data']):
    dims={v['concept']:v for v in row['variable']};geo=dims['Country']['id'];year=int(dims['Time']['value'])
    if geo not in known or not 2000<=year<=2025:
     exclusions.append({'source_file':'raw/'+file,'row_index':idx,'reason':'Aggregate or outside selected native year range','geo_id':geo});continue
    records.append({'series_id':s['id'],'geo_id':geo,'geo_name':known[geo],'year':year,'source_year':year,
                    'value':row['value'],'unit':s['unit'],'status':'published_modeled_diet_estimate' if finite(row['value']) else 'source_missing',
                    'status_label':'Published FAO/World Bank modeled diet estimate' if finite(row['value']) else 'Unavailable in source',
                    'estimate':True,'derived_locally':False,'source_adjusted':code=='CoHD_PPP','eligible':finite(row['value']),
                    'classification':dims.get('Classification',{}).get('id'),'source_id':'global:'+file,
                    'source_record_ref':'raw/'+file+'#/source/data/'+str(idx),'source_record_refs':['raw/'+file+'#/source/data/'+str(idx)],
                    'source_record':row,'residual_eligible':False})
  series.append(s)
  rs=[r for r in records if r['series_id']==s['id']];numeric=[r for r in rs if finite(r['value'])]
  counts[s['id']]={'retained_records':len(rs),'numerical_values':len(numeric),'missing_values':len(rs)-len(numeric),'economies_with_values':len({r['geo_id']for r in numeric}),'first_year':min((r['year']for r in numeric),default=None),'last_year':max((r['year']for r in numeric),default=None)}
 keys=[(r['series_id'],r['geo_id'],r['year'])for r in records]
 if len(keys)!=len(set(keys)):raise ValueError('Duplicate native global context keys')
 packet={'schema':'essentials-costs.global-context/v1','prepared_utc':datetime.now(timezone.utc).isoformat(),
         'series':series,'countries':[{'id':k,'name':v}for k,v in sorted(known.items())],
         'records':records,'sources':sources,'coverage':counts,
         'limitations':['These global context measures are not components of a matched income-minus-essentials residual. Denominators, sources and price bases remain separate.',
                        'Current international-dollar healthcare and diet costs are not constant-2021 welfare values. No local PPP or inflation conversion is applied.',
                        'Out-of-pocket health share means share of total current health expenditure, not share of household income.',
                        'Healthy-diet costs are least-cost modeled benchmarks for a representative 2,330 kcal/day person, not actual food expenditure or a universal individual nutrition prescription.',
                        'Food source FPN 5.0 (July 2026) uses updated income/poverty conventions; the archived July 2025 method brief describes price updating but is not the authority for the 2026 poverty thresholds.',
                        'National averages do not describe each household. Missing source cells remain missing; no local interpolation, nearest-year substitution, or zero replacement is used.']}
 raw=(json.dumps(packet,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode();(ROOT/'global_context_module.json').write_bytes(raw)
 (ROOT/'SOURCE_INDEX.json').write_text(json.dumps({'sources':sources},ensure_ascii=False,indent=2)+'\n')
 (ROOT/'EXCLUSION_LEDGER.json').write_text(json.dumps(exclusions,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'COVERAGE.json').write_text(json.dumps({'packet_bytes':len(raw),'packet_sha256':hashlib.sha256(raw).hexdigest(),'series':counts,'excluded_native_rows_retained_in_raw':len(exclusions)},indent=2)+'\n')
 with (ROOT/'global_context_values.csv').open('w',newline='')as f:
  columns=['series_id','geo_id','geo_name','year','value','unit','status','source_id','source_record_ref']
  out=csv.DictWriter(f,fieldnames=columns);out.writeheader();out.writerows({k:r.get(k)for k in columns}for r in records)
 print(json.dumps({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'records':len(records),'coverage':counts},indent=2))


if __name__=='__main__':main()
