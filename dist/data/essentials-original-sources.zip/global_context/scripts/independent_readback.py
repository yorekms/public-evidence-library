"""Check archived original bytes and native extraction without using the builder."""
from pathlib import Path
import json,hashlib,math
from collections import Counter

ROOT=Path(__file__).resolve().parents[1]
raw=(ROOT/'global_context_module.json').read_bytes();d=json.loads(raw)
failures=[];field_checks=0;hash_checks=0;cache={}
for s in d['sources']:
 b=(ROOT/s['file']).read_bytes();hash_checks+=1
 if len(b)!=s['bytes']or hashlib.sha256(b).hexdigest()!=s['sha256']:failures.append('source hash '+s['file'])
for row in d['records']:
 file,pointer=row['source_record_ref'].split('#',1)
 if file not in cache:cache[file]=json.loads((ROOT/file).read_text())
 native=cache[file]
 for part in pointer.strip('/').split('/'):
  native=native[int(part)]if isinstance(native,list)else native[part]
 expected={'value':native['value'],'source_record':native,'residual_eligible':False}
 if row['series_id'].startswith('wdi::'):
  expected.update(geo_id=native['countryiso3code'],year=int(native['date']),source_year=int(native['date']),native_obs_status=native.get('obs_status',''),native_footnote=native.get('footnote',''))
 else:
  dims={v['concept']:v for v in native['variable']}
  expected.update(geo_id=dims['Country']['id'],year=int(dims['Time']['value']),source_year=int(dims['Time']['value']),classification=dims['Classification']['id'])
 for key,value in expected.items():
  field_checks+=1
  if row.get(key)!=value:failures.append(f"{row['series_id']}/{row['geo_id']}/{row['year']}/{key}")
 if row['source_record_refs']!=[row['source_record_ref']]:failures.append('plural ref '+row['source_record_ref'])
 if row['derived_locally']is not False:failures.append('local derived flag')
 if row['eligible']is not(isinstance(row['value'],(int,float))and not isinstance(row['value'],bool)and math.isfinite(row['value'])):failures.append('eligibility '+row['source_record_ref'])
keys=[(r['series_id'],r['geo_id'],r['year'])for r in d['records']]
duplicate_count=len(keys)-len(set(keys))
if duplicate_count:failures.append('duplicate native keys')
report={'schema':'essentials-costs.global-context-readback/v1','packet_sha256':hashlib.sha256(raw).hexdigest(),'packet_bytes':len(raw),'raw_source_hash_checks':hash_checks,'native_records_checked':len(d['records']),'native_field_checks':field_checks,'duplicate_keys':duplicate_count,'all_records_preserve_native_published_value':True,'no_local_conversion_or_interpolation':True,'all_series_excluded_from_residual':all(s['residual_eligible']is False for s in d['series']),'failures':failures}
(ROOT/'INDEPENDENT_READBACK.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
if failures:raise SystemExit(1)
