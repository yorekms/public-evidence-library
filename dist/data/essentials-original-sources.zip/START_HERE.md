# Essentials: housing, food, home energy and healthcare

[Open Essentials & resources](https://public-evidence-library-yorek.tasty-siren-3221.chatgpt.site/#essentials), or [open the local economic models](http://127.0.0.1:8772/pipelines.html?view=economics#economic-essentials-context). The existing resource maps, household-income explorer, GDP/PPP comparisons, numerical catalogue and original model accounts remain available.

The first section estimates resources remaining for other spending and saving after a selected national-account consumption basket. It keeps domestic category spending, resident household income and resident consumption separate, then shows its explicit proportional-allocation assumption. The default is Germany and France in 2023, COICOP 2018, gross disposable income. Select a source year, country, comparison country, classification edition, gross/net income and included categories.

Current-classification default estimates are available for 678 country-years in 28 economies. Legacy-classification gross-income estimates cover 668 country-years in 30 economies. The input ledger covers a wider union of 38 economies; missing or incompatible inputs produce unavailable estimates. The 1999 and 2018 classifications are never stitched together.

The separate global section offers fourteen measures, including original food/health benchmarks and derived domestic category shares. Healthcare observations cover 193 economies; healthy-diet PPP costs cover 167. U.S., Canadian, British and Japanese category-share histories are available even though a compatible income remainder is not supplied for them. They retain their source classification and denominator.

Use **Download originals, estimates and model context** for source inputs, formulas, estimates, histories, source hashes and copies of currently loaded original model results. CSV histories are also available. The source ZIP retains the original API/CSV responses, full research modules, metadata, scripts and audit receipts. The installed interface uses curated JSON packets below the hosting file-size limit; the larger source modules remain in this companion folder and ZIP.

Read ESSENTIALS_COSTS.md for category definitions, price/territory boundaries, allocation formulas, source-coherence ranges, coverage and the Python research workflow. Source-specific guides are CATEGORIES_SOURCE_GUIDE.md, OECD_CATEGORIES_PROBE_GUIDE.md, income_alignment/SOURCE_GUIDE.md and global_context/GLOBAL_CONTEXT_SOURCE_GUIDE.md.

The original local service continues running without a restart. The new Python helper is workbench/essentials_costs.py in the existing workbench. Browser reporting and the Python helper use matching deterministic calculations; no industry model coefficients are changed or household outcome forecast inferred.
