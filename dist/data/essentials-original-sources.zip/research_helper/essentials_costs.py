"""Deterministic, source-preserving household essential-cost allocations.

The point estimate applies a domestic category mix to resident household
consumption. It is an explicit allocation assumption, not an observed resident
category budget or a prediction of household outcomes from an industry shock.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

UNIT = 'current million EUR'
EPS = 1e-8
DEFAULT_CATEGORIES = ('food', 'housing', 'energy', 'healthcare')
CLASSIFICATIONS = ('COICOP 2018', 'COICOP 1999')
ASSUMPTIONS = [
    'Resident category spending is estimated by applying observed domestic category shares to resident household consumption. Equal domestic/resident category composition is an analyst assumption.',
    'Households (S14), the exact country/year, one COICOP classification and additive current-million-EUR values are required. Missing data are not replaced or carried forward.',
    'Housing excludes home energy (CP04 minus CP045), so selecting housing and energy does not count energy twice.',
    'The remainder is aggregate disposable income after the selected estimated consumption categories; other consumption and saving remain. It is not a median cash budget or an official saving rate.',
    'Gross income is before consumption of fixed capital; net income is a separate source basis. National-account housing includes imputed rent, and health excludes social transfers in kind.',
    'Optional bounds are an allocation constraint under coherent national/domestic/tourism aggregates, not a confidence or credible interval. Source discrepancies are retained and never forced equal.',
    'Current-EUR values retain inflation and exchange-rate effects. No GDP PPP, household PPP or price adjustment is applied by this calculation.',
]


def _finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _valid_year(value):
    return _finite(value) and float(value).is_integer()


def _request_year(value):
    if isinstance(value, bool):
        raise ValueError('Choose an integer native reporting year.')
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValueError('Choose an integer native reporting year.') from None
    if not math.isfinite(result) or not result.is_integer():
        raise ValueError('Choose an integer native reporting year; dates are not rounded.')
    return int(result)


def _empty(row, options):
    source = row if isinstance(row, dict) else {}
    return {
        'schema': 'essentials-costs.allocation-report/v1', 'available': False,
        'status': 'unavailable', 'reason': None, 'original': copy.deepcopy(row),
        'geo_id': source.get('geo_id'), 'geo_name': source.get('geo_name'), 'year': source.get('year'),
        'classification': source.get('classification'), 'unit': UNIT,
        'income_basis': options.get('income_basis', 'gross'),
        'selected_categories': copy.deepcopy(options.get('selected_categories', list(DEFAULT_CATEGORIES))),
        'income': None, 'domestic_total': None, 'resident_consumption': None,
        'domestic_components': dict.fromkeys(DEFAULT_CATEGORIES),
        'estimated_resident_components': dict.fromkeys(DEFAULT_CATEGORIES),
        'component_income_shares': dict.fromkeys(DEFAULT_CATEGORIES),
        'native_selected_cost': None, 'domestic_essential_share': None,
        'estimated_resident_essentials': None, 'remaining_amount': None, 'remaining_share': None,
        'allocation_bounds': {'available': False, 'reason': 'Point estimate unavailable.',
                              'remaining_share_lower': None, 'remaining_share_upper': None,
                              'remaining_amount_lower': None, 'remaining_amount_upper': None,
                              'source_coherence_residuals': {'bridge_identity': None, 'bridge_domestic_vs_category': None,
                                                             'bridge_national_vs_resident': None}},
        'assumptions': list(ASSUMPTIONS),
    }


def estimate_row(row, options=None):
    """Estimate one original source row, preserving it in every report."""
    options = {} if options is None else options
    if not isinstance(options, dict):
        options = {'income_basis': 'invalid_options'}
    report = _empty(row, options)

    def fail(status, reason):
        report.update(status=status, reason=reason)
        return report

    if (not isinstance(row, dict) or not isinstance(row.get('geo_id'), str)
            or not row['geo_id'] or not _valid_year(row.get('year'))):
        return fail('invalid_row', 'A source row needs an exact country and integer native reporting year.')
    if row.get('classification') not in CLASSIFICATIONS:
        return fail('invalid_classification', 'Use one retained COICOP 2018 or COICOP 1999 source classification.')
    if row.get('unit') != UNIT:
        return fail('incompatible_unit', 'The allocation requires additive current million EUR, not chain-linked volumes or another currency/scale.')
    if report['income_basis'] not in ('gross', 'net'):
        return fail('invalid_income_basis', 'Choose gross or net disposable income explicitly.')
    selected = report['selected_categories']
    if (not isinstance(selected, (list, tuple)) or not selected
            or any(not isinstance(k, str) or k not in DEFAULT_CATEGORIES for k in selected)
            or len(set(selected)) != len(selected)):
        return fail('invalid_categories', 'Choose at least one distinct supported category: food, housing, energy or healthcare.')
    report['selected_categories'] = list(selected)
    inputs = row.get('inputs') if isinstance(row.get('inputs'), dict) else {}

    def source(name, scope, classification=False, items=None, direction=None):
        item = inputs.get(name)
        if not isinstance(item, dict) or not _finite(item.get('value')):
            return False, 'Missing or non-finite ' + name + ' source value.'
        if item.get('geo_id') != row['geo_id'] or not _valid_year(item.get('year')) or item['year'] != row['year']:
            return False, 'The ' + name + ' source does not match the exact country/reporting year.'
        if item.get('sector') != 'S14':
            return False, 'The ' + name + ' source must describe households (S14); NPISH totals cannot substitute.'
        if item.get('unit') != UNIT or item.get('native_unit_code') != 'CP_MEUR':
            return False, 'The ' + name + ' source must use original additive current million EUR (CP_MEUR).'
        if item.get('territorial_basis') != scope:
            return False, 'The ' + name + ' source has an incompatible resident/domestic territorial basis.'
        if classification and item.get('classification') != row['classification']:
            return False, 'The ' + name + ' source has a missing or different COICOP classification.'
        expected_category = {'domestic_total': 'TOTAL', 'food': 'CP01', 'housing_including_energy': 'CP04', 'energy': 'CP045', 'healthcare': 'CP06'}.get(name)
        if classification and item.get('source_category') != expected_category:
            return False, 'The ' + name + ' source has a missing or incompatible COICOP category code.'
        if items and item.get('na_item') not in items:
            return False, 'The ' + name + ' source has an incompatible income/consumption accounting item.'
        if direction and item.get('direct') != direction:
            return False, 'The ' + name + ' source has an incompatible transaction direction.'
        if item.get('eligible') is False:
            return False, 'The ' + name + ' source is explicitly ineligible.'
        return True, item['value']

    income_name = 'income_gross' if report['income_basis'] == 'gross' else 'income_net'
    income_source = source(income_name, 'resident', items=['B6G' if report['income_basis'] == 'gross' else 'B6N'], direction='RECV')
    domestic_source = source('domestic_total', 'domestic', True)
    resident_source = source('resident_consumption', 'resident', items=['P3', 'P31_S14', 'P31_S14_NC'], direction='PAID')
    for valid, result in [income_source, domestic_source, resident_source]:
        if not valid:
            return fail('missing_or_incompatible_input', result)
    income, domestic, resident = income_source[1], domestic_source[1], resident_source[1]
    report.update(income=income, domestic_total=domestic, resident_consumption=resident)
    if income <= 0 or domestic <= 0 or resident < 0:
        return fail('inadmissible_account_totals', 'Income and domestic total must be positive; resident consumption must be nonnegative.')
    raw = {k: source(k, 'domestic', True) for k in ['food', 'housing_including_energy', 'energy', 'healthcare']}
    reasons = {}
    for key in ['food', 'energy', 'healthcare']:
        valid, value = raw[key]
        if valid and value >= 0:
            report['domestic_components'][key] = value
        else:
            reasons[key] = 'The ' + key + ' source is negative.' if valid else value
    housing, energy = raw['housing_including_energy'], raw['energy']
    if housing[0] and energy[0] and housing[1] >= 0 and energy[1] >= 0 and housing[1] >= energy[1]:
        report['domestic_components']['housing'] = housing[1] - energy[1]
    else:
        reasons['housing'] = (housing[1] if not housing[0] else energy[1] if not energy[0]
                              else 'Housing including energy must be nonnegative and at least as large as home energy.')
    report['component_reasons'] = reasons
    for key in selected:
        if report['domestic_components'][key] is None:
            return fail('missing_or_incompatible_category', reasons[key])
    essential = sum(report['domestic_components'][k] for k in selected)
    if not _finite(essential) or essential > domestic:
        return fail('inadmissible_category_total', 'The nonoverlapping selected domestic categories exceed the domestic total.')
    share = essential / domestic
    estimate = resident * share
    remainder = income - estimate
    remainder_share = remainder / income * 100
    if not all(_finite(v) for v in (estimate, remainder, remainder_share)):
        return fail('non_finite_calculation', 'The allocation calculation did not produce a finite value.')
    report.update(native_selected_cost=essential, domestic_essential_share=share,
                  estimated_resident_essentials=estimate, remaining_amount=remainder,
                  remaining_share=remainder_share,
                  available=True, status='estimated_proportional_resident_allocation', reason=None)
    for key, value in report['domestic_components'].items():
        if value is not None:
            amount = resident * (value / domestic)
            percent = amount / income * 100
            if _finite(amount) and _finite(percent):
                report['estimated_resident_components'][key] = amount
                report['component_income_shares'][key] = percent
    bridge_domestic = source('bridge_domestic', 'domestic', items=['P31_S14_DC'])
    bridge_national = source('bridge_national', 'resident', items=['P31_S14_NC', 'P31_S14'])
    abroad = source('resident_abroad', 'resident', items=['P33'])
    inbound = source('nonresident_domestic', 'domestic', items=['P34'])
    bounds = report['allocation_bounds']
    for valid, value in [bridge_domestic, bridge_national, abroad, inbound]:
        if not valid:
            bounds['reason'] = value
            return report
    bd, bn, outbound, inbound_value = bridge_domestic[1], bridge_national[1], abroad[1], inbound[1]
    residuals = {'bridge_identity': bn - (bd + outbound - inbound_value),
                 'bridge_domestic_vs_category': bd - domestic,
                 'bridge_national_vs_resident': bn - resident}
    bounds['source_coherence_residuals'] = residuals
    if (min(bd, bn, outbound, inbound_value) < 0 or outbound > bn + EPS or inbound_value > bd + EPS):
        bounds['reason'] = 'Bridge totals and tourism flows must be nonnegative and admissible within their corresponding totals.'
        return report
    if any(abs(v) > EPS for v in residuals.values()):
        bounds['reason'] = 'Source-coherence check failed; original cross-table and bridge residuals are retained.'
        return report
    low_cost, high_cost = max(0, essential - inbound_value), min(resident, essential + outbound)
    if low_cost > high_cost:
        bounds['reason'] = 'The source-constrained cost bounds are inconsistent.'
        return report
    report['allocation_bounds'] = {
        'available': True, 'reason': None, 'label': 'Allocation constraint range; not a confidence or credible interval',
        'estimated_cost_lower': low_cost, 'estimated_cost_upper': high_cost,
        'remaining_amount_lower': income - high_cost, 'remaining_amount_upper': income - low_cost,
        'remaining_share_lower': (income - high_cost) / income * 100,
        'remaining_share_upper': (income - low_cost) / income * 100,
        'source_coherence_residuals': residuals, 'absolute_coherence_tolerance_million_EUR': EPS,
    }
    return report


class EssentialsCosts:
    """Read a frozen packet and select exact source country/year/classification rows."""

    def __init__(self, root_or_packet):
        if isinstance(root_or_packet, dict):
            self.data = copy.deepcopy(root_or_packet)
            raw = json.dumps(self.data, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
        else:
            path = Path(root_or_packet)
            if path.is_dir():
                path = path / 'data' / 'essentials_costs' / 'budget.json'
            raw = path.read_bytes()
            self.data = json.loads(raw)
        if self.data.get('schema') != 'essentials-costs.budget-data/v1':
            raise ValueError('Unknown essential-cost source format.')
        self.fingerprint = hashlib.sha256(raw).hexdigest()
        self.index = defaultdict(list)
        for row in self.data.get('rows', []):
            self.index[(row.get('geo_id'), row.get('year'), row.get('classification'))].append(row)

    def estimate(self, country, year, classification='COICOP 2018', income_basis='gross', selected_categories=DEFAULT_CATEGORIES):
        year = _request_year(year)
        options = {'income_basis': income_basis, 'selected_categories': list(selected_categories) if isinstance(selected_categories, tuple) else selected_categories}
        rows = self.index.get((str(country), year, classification), [])
        if len(rows) == 1:
            report = estimate_row(rows[0], options)
        else:
            report = _empty(None, options)
            report.update(geo_id=str(country), year=year, classification=classification,
                          status='ambiguous_source_rows' if rows else 'no_exact_country_year_classification',
                          reason='Multiple original source rows match; no row is selected or averaged.' if rows else 'No exact country/year/classification source row is available.')
            if rows:
                report['ambiguous_rows'] = copy.deepcopy(rows)
        report['source_packet_sha256'] = self.fingerprint
        return report

    def panel(self, countries, years, classification='COICOP 2018', income_basis='gross', selected_categories=DEFAULT_CATEGORIES, *, complete_cases=False):
        countries = list(dict.fromkeys(str(c) for c in countries))
        years = list(dict.fromkeys(_request_year(y) for y in years))
        all_rows = [self.estimate(country, year, classification, income_basis, selected_categories) for country in countries for year in years]
        excluded = [r for r in all_rows if complete_cases and not r['available']]
        included = [r for r in all_rows if not complete_cases or r['available']]
        return {'schema': 'essentials-costs.research-panel/v1', 'source_packet_sha256': self.fingerprint,
                'classification': classification, 'income_basis': income_basis,
                'selected_categories': list(selected_categories) if isinstance(selected_categories, tuple) else selected_categories,
                'rows': included, 'excluded_rows': excluded,
                'row_accounting': {'requested_country_years': len(all_rows), 'included_country_years': len(included),
                                   'excluded_country_years': len(excluded), 'unavailable_estimates': sum(not r['available'] for r in all_rows),
                                   'complete_case_filter_explicit': complete_cases},
                'sources': copy.deepcopy(self.data.get('sources', [])), 'limitations': copy.deepcopy(self.data.get('limitations', [])),
                'model_solve_performed': False}

    def attach_to_model(self, original_evidence, classification='COICOP 2018', income_basis='gross', selected_categories=DEFAULT_CATEGORIES):
        if not isinstance(original_evidence, dict):
            raise ValueError('Provide original economic result/evidence JSON.')
        result = original_evidence.get('result', original_evidence)
        if not isinstance(result, dict) or result.get('country') is None or result.get('year') is None:
            raise ValueError('The original model result needs its exact source country and reporting year.')
        report = self.estimate(result['country'], result['year'], classification, income_basis, selected_categories)
        return {'schema': 'essentials-costs.model-evidence/v1',
                'original_model_evidence': copy.deepcopy(original_evidence), 'essentials_context': report,
                'source_packet_sha256': self.fingerprint, 'sources': copy.deepcopy(self.data.get('sources', [])),
                'limitations': copy.deepcopy(self.data.get('limitations', [])), 'model_coefficients_changed': False,
                'model_recomputed': False, 'household_response_to_industry_shock_predicted': False}


def main(argv=None):
    parser = argparse.ArgumentParser(description='Attach explicit essentials-allocation context to preserved original model evidence.')
    parser.add_argument('--data', required=True, help='Frozen budget.json packet or installed workbench root.')
    parser.add_argument('--input', required=True, help='Original economic result/evidence JSON.')
    parser.add_argument('--output', required=True, help='New evidence JSON; existing files are never overwritten.')
    parser.add_argument('--classification', choices=CLASSIFICATIONS, default='COICOP 2018')
    parser.add_argument('--income-basis', choices=['gross', 'net'], default='gross')
    parser.add_argument('--categories', nargs='+', choices=DEFAULT_CATEGORIES, default=list(DEFAULT_CATEGORIES))
    args = parser.parse_args(argv)
    source, target = Path(args.input), Path(args.output)
    if target.exists() or source.resolve() == target.resolve():
        parser.error('Choose a new output file; original evidence, source packets and existing artifacts are preserved.')
    raw = source.read_bytes()
    result = EssentialsCosts(args.data).attach_to_model(json.loads(raw), args.classification, args.income_basis, args.categories)
    result['original_model_evidence_sha256'] = hashlib.sha256(raw).hexdigest()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
