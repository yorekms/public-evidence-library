"""Combine preserved source modules; add explicit within-country income rebasing."""
from pathlib import Path
import copy
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]


def finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def build():
    w = json.loads((ROOT / 'wdi_household_module.json').read_text())
    i = json.loads((ROOT / 'income_sources/income_packet.json').read_text())
    wanted = {'derived::HFCE_PC_PPP_2021', 'wdi::PA.NUS.PRVT.PLI',
              'wdi::FP.CPI.TOTL', 'derived::CPI_2021_100'}
    definitions = []
    for original in i['series']:
        s = copy.deepcopy(original)
        s['label'] = s['name']
        s['native_definition'] = s['definition']
        pip = s['id'].startswith('pip::')
        income = '::income::' in s['id'] or s['id'].startswith('oecd::')
        s['concept'] = 'income' if income else 'consumption'
        s['source_ids'] = [s['source_id']]
        s['frequency'] = 'actual national survey reporting years' if pip else 'annual, available source years'
        s['cross_country_eligible'] = pip
        s['temporal_eligible'] = True
        s['requires_comparability_group'] = True
        s['adjustment'] = ('Published survey estimate, adjusted by source to constant 2021 PPP'
                           if pip else 'Original annual income at current national-currency prices')
        s['interpretation'] = ('Qualified comparison of the same survey welfare concept and statistic; retain survey definitions, reporting years and comparability spells. Values are per person per day.'
                               if pip else 'Within-country nominal income history. Household-size equivalisation differs from per-person survey values. National currencies are not ranked across countries.')
        definitions.append(s)
    for original in w['series']:
        if original['id'] not in wanted:
            continue
        s = copy.deepcopy(original)
        s['frequency'] = 'annual, available source years'
        s['cross_country_eligible'] = s['id'] in {'derived::HFCE_PC_PPP_2021', 'wdi::PA.NUS.PRVT.PLI'}
        s['temporal_eligible'] = True
        s['requires_comparability_group'] = False
        s['interpretation'] = {
            'derived::HFCE_PC_PPP_2021': 'National-account household and nonprofit-institution consumption divided by same-year total population. This is an average, including consumption such as imputed housing services, not a median cash budget.',
            'wdi::PA.NUS.PRVT.PLI': 'Consumer price-level context relative to the United States in the same year: 80 means a broad household-consumption price level about 20% below the U.S. reference. Changes reflect relative prices and exchange rates, not national inflation alone.',
            'wdi::FP.CPI.TOTL': 'National consumer-price change over time, 2010 = 100. Index levels do not rank living costs across countries.',
            'derived::CPI_2021_100': 'National CPI divided by that country’s 2021 CPI, multiplied by 100. A value of 110 indicates prices about 10% above that country’s 2021 level; it is not a cross-country cost ranking.',
        }[s['id']]
        s['adjustment'] = ('Calculated per-person estimate from published constant-2021 PPP consumption and population' if s['id'] == 'derived::HFCE_PC_PPP_2021'
                           else 'Calculated within-country rebase; 2021 = 100' if s['id'] == 'derived::CPI_2021_100'
                           else 'Published national index; source estimation and compilation methods retained')
        definitions.append(s)
    records = []
    for original in i['records']:
        r = copy.deepcopy(original)
        r['eligible'] = finite(r['value'])
        ref = copy.deepcopy(r['source_record_ref'])
        ref['file'] = 'income_sources/' + ref['file']
        r['source_record_ref'] = copy.deepcopy(ref)
        r['source_record_refs'] = [ref]
        records.append(r)
    windex = {(r['series_id'], r['geo_id'], r['year']): r for r in w['records']}
    for original in w['records']:
        if original['series_id'] not in wanted:
            continue
        r = copy.deepcopy(original)
        r['eligible'] = finite(r.get('value'))
        r['estimate'] = True
        r['derived_locally'] = r['series_id'].startswith('derived::')
        r['source_adjusted'] = r['series_id'] == 'derived::HFCE_PC_PPP_2021'
        if 'source_record_refs' not in r:
            r['source_record_refs'] = [r['source_record_ref']] if r.get('source_record_ref') else []
        r['status_label'] = ('Calculated from retained source inputs' if r['derived_locally'] else 'Published national-account or price-index estimate') if r['eligible'] else 'Unavailable: missing required source value'
        records.append(r)
    derived = []
    for statistic in ('median', 'mean'):
        native_id = f'oecd::IDD::{statistic}_disposable_native'
        series_id = f'derived::OECD_{statistic.upper()}_DISPOSABLE_CPI_2021'
        native_series = next(s for s in definitions if s['id'] == native_id)
        s = copy.deepcopy(native_series)
        s.update(id=series_id, label=f'{statistic.title()} disposable household income, national 2021 prices',
                 unit='2021 national currency per equivalent household member per year',
                 price_basis='Calculated national CPI adjustment to that country’s 2021 prices',
                 adjustment='Analyst-calculated estimate: original income × country CPI(2021) / country CPI(income year)',
                 source_ids=[native_series['source_id'], 'wdi:wdi_data_FP.CPI.TOTL'],
                 source_adjusted=False,
                 interpretation='Within-country inflation-adjusted equivalised disposable income. Retain the record currency code and source definition. Different national currencies remain separate; no GDP or consumption PPP factor is applied to this income series.')
        definitions.append(s)
        for original in [r for r in records if r['series_id'] == native_id]:
            r = {k: copy.deepcopy(v) for k, v in original.items() if k != 'source_record'}
            current = windex.get(('wdi::FP.CPI.TOTL', r['geo_id'], r['year']))
            base = windex.get(('wdi::FP.CPI.TOTL', r['geo_id'], 2021))
            valid = (original.get('eligible') is not False and finite(original['value'])
                     and current and base and finite(current['value']) and current['value'] > 0
                     and finite(base['value']) and base['value'] > 0)
            multiplier = base['value'] / current['value'] if valid else None
            r.update(series_id=series_id, value=original['value'] * multiplier if valid else None,
                     unit=s['unit'], source_id='derived:oecd-income-national-cpi',
                     status='derived_national_cpi_income_estimate' if valid else 'missing_required_input',
                     status_label='Calculated estimate using matched national CPI' if valid else 'Unavailable: missing original income or national CPI',
                     estimate=True, derived_locally=True, source_adjusted=False, eligible=bool(valid),
                     original_income_series_id=native_id, original_income=original['value'],
                     multiplier=multiplier, base_year=2021,
                     formula='original income × same-country CPI(2021) / same-country CPI(income year)')
            r.pop('source_record_ref', None)
            r['inputs'] = [{'series_id': native_id, 'year': original['year'], 'value': original['value'],
                            'currency': original.get('currency'), 'source_record_refs': copy.deepcopy(original['source_record_refs'])}]
            for row, year in [(current, original['year']), (base, 2021)]:
                r['inputs'].append({'series_id': 'wdi::FP.CPI.TOTL', 'year': year,
                                    'value': row['value'] if row else None,
                                    'source_record_ref': row.get('source_record_ref') if row else None})
                if row and row.get('source_record_ref'):
                    r['source_record_refs'].append(row['source_record_ref'])
            derived.append(r)
    records.extend(derived)
    country_names = {c['id']: c['name'] for c in w['countries']}
    for r in records:
        country_names.setdefault(r['geo_id'], r['geo_name'])
    sources = copy.deepcopy(w['sources'])
    for original in i['sources']:
        s = copy.deepcopy(original)
        s['title'] = s.get('name', s['id'])
        if s.get('file'):
            s['file'] = 'income_sources/' + s['file']
        sources.append(s)
    sources.extend([
        {'id': 'derived:wdi_household', 'title': 'Explicit per-person and CPI-rebasing calculations',
         'url': 'https://data.worldbank.org/indicator/NE.CON.PRVT.PP.KD', 'file': 'scripts/acquire_wdi_household.py'},
        {'id': 'derived:oecd-income-national-cpi', 'title': 'OECD income rebased using the same country’s published CPI',
         'url': 'https://data.worldbank.org/indicator/FP.CPI.TOTL', 'file': 'scripts/build_household_packet.py'},
    ])
    limitations = list(dict.fromkeys([
        'National averages, survey medians, equivalised disposable income, consumer price levels and inflation indices retain different concepts and denominators; they are not combined into a household budget or universal affordability score.',
        'Published survey, national-account and PPP/index values are estimates or compiled statistics. Blank native status fields do not certify direct measurement; original flags, footnotes and source methods remain available.',
        'PIP uses native reporting years for maps and exact survey years in source context. Survey comparability spells and welfare types remain distinct. No missing survey years are interpolated or carried forward locally.',
        'Published constant-2021 PPP income and consumption values are not adjusted again. Local derived estimates identify all inputs and formulas.',
        'Price-level indices compare countries against the United States in each year; national CPI index levels support within-country price change and cannot rank countries by living costs.',
        'OECD original and CPI-adjusted income retain national currencies, equivalisation and methodology. National currencies are not compared as equal units across countries.',
        'Consumption includes nonprofit institutions serving households and national-account imputations. It measures consumption, not necessarily out-of-pocket cash expenditure.',
        'These are source-attached household research covariates. No industry demand shock is automatically translated into household income, prices, inequality or welfare effects.',
        'Exact country/reporting-year joins only. Missing values, unmatched countries and rest-of-world remain unavailable; no GDP-per-person household substitute is supplied.',
    ] + w.get('limitations', []) + i.get('limitations', [])))
    counts = {}
    for s in definitions:
        rows = [r for r in records if r['series_id'] == s['id']]
        numeric = [r for r in rows if finite(r.get('value')) and r.get('eligible') is not False]
        counts[s['id']] = {'records': len(rows), 'numerical_values': len(numeric),
                           'missing_values': len(rows) - len(numeric),
                           'economies_with_values': len({r['geo_id'] for r in numeric})}
    packet = {'schema': 'household-affordability/v1',
              'prepared_utc': datetime.now(timezone.utc).isoformat(),
              'period': [2000, 2025], 'reference_price_year': 2021,
              'series': definitions, 'countries': [{'id': k, 'name': v} for k, v in sorted(country_names.items(), key=lambda p:p[1])],
              'records': records, 'sources': sources, 'limitations': limitations,
              'methods': {'source_versions': {'WDI': '2026-10-08', 'PIP': '20260922_2021_01_02_PROD', 'OECD_IDD': 'retrieved 2026-10-31; METH2012 + D_CUR'},
                          'source_modules': [{'file': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in [ROOT/'wdi_household_module.json', ROOT/'income_sources/income_packet.json']],
                          'no_annual_survey_gap_fill': True, 'model_coefficients_changed': False,
                          'original_income_and_wdi_modules_retained': True},
              'coverage': {'series': len(definitions), 'records': len(records), 'economies': len(country_names),
                           'numerical_values': sum(x['numerical_values'] for x in counts.values()), 'by_series': counts}}
    keys = [(r['series_id'], r['geo_id'], r['year']) for r in records]
    if len(keys) != len(set(keys)):
        raise ValueError('Duplicate household native reporting-year keys; do not silently select.')
    raw = (json.dumps(packet, ensure_ascii=False, separators=(',', ':'), allow_nan=False)+'\n').encode()
    path = ROOT/'household.json'
    path.write_bytes(raw)
    manifest = {'schema': packet['schema'], 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'coverage': packet['coverage']}
    (ROOT/'HOUSEHOLD_MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    build()
