#!/usr/bin/env python3
"""Archive and normalize original WDI household-account and price data."""
from __future__ import annotations
import csv, datetime as dt, hashlib, json, math, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import requests

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'sources'
YEARS = list(range(2000, 2026))
DEFS = {
 'NE.CON.PRVT.PP.KD': ('Household and NPISH consumption, constant 2021 PPP', 'constant 2021 international dollars', 'consumption', 'National-account household and nonprofit-institution consumption total; already in constant 2021 PPP prices.'),
 'NE.CON.PRVT.CN': ('Household and NPISH consumption, current local currency', 'current local currency units', 'consumption', 'National-account household and nonprofit-institution consumption total, unadjusted current local currency.'),
 'NE.CON.PRVT.CD': ('Household and NPISH consumption, current U.S. dollars', 'current USD', 'consumption', 'National-account household and nonprofit-institution consumption total, unadjusted current U.S. dollars.'),
 'NE.CON.PRVT.PC.KD': ('Household and NPISH consumption per person, constant 2015 USD', 'constant 2015 USD per person', 'consumption', 'Published national-account average per person at constant 2015 U.S. dollar prices; not the PPP measure.'),
 'PA.NUS.PRVT.PP': ('Household consumption PPP conversion factor', 'local currency units per current international dollar', 'conversion_factor', 'Published PPP conversion factor for household and nonprofit-institution consumption; do not use to convert industry or trade flows.'),
 'PA.NUS.PRVT.PLI': ('Household consumption price level, United States = 100', 'index, United States = 100 in the same year', 'relative_consumer_price_level', 'Published spatial household-consumption price level; a broad price context, not a household-specific minimum living-cost budget.'),
 'PA.NUS.FCRF': ('Official exchange rate, annual average', 'local currency units per current USD', 'exchange_rate', 'Official annual average exchange rate. Retained for audit and context; not substituted for missing PPP or price-level observations.'),
 'FP.CPI.TOTL': ('Consumer price index, national 2010 = 100', 'index, national 2010 = 100', 'consumer_price_change', 'Within-country consumer price history. National CPI index levels cannot rank cost of living across countries.'),
 'SP.POP.TOTL': ('Population, total', 'people', 'population', 'Published midyear resident population estimate used only for same-country, same-year per-person calculations.'),
}

def get(url, name):
    path = SOURCE / name
    if not path.exists():
        for attempt in range(5):
            try:
                r = requests.get(url, timeout=100, headers={'User-Agent':'Mozilla/5.0 PublicDataWorkbench source archive'})
                r.raise_for_status()
                parsed = r.json()
                if not isinstance(parsed,list) or len(parsed)<2 or not isinstance(parsed[1],list):
                    raise ValueError(str(parsed)[:300])
                path.write_bytes(r.content)
                break
            except Exception:
                if attempt == 4: raise
                time.sleep(attempt+1)
    raw=path.read_bytes(); data=json.loads(raw)
    return data, {'id':'wdi:'+name.removesuffix('.json'), 'file':'sources/'+name, 'url':url,
        'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
        'retrieved_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'license':'CC BY 4.0 (World Bank indicator pages)',
        'api_header':data[0]}

def finite(value): return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)

def main():
    SOURCE.mkdir(parents=True,exist_ok=True)
    jobs=[('countries','https://api.worldbank.org/v2/country?format=json&per_page=400','wdi_countries.json')]
    for code in DEFS:
        jobs.extend([(code+':metadata',f'https://api.worldbank.org/v2/indicator/{code}?format=json&source=2',f'wdi_metadata_{code}.json'),
            (code+':data',f'https://api.worldbank.org/v2/country/all/indicator/{code}?format=json&source=2&date=2000:2025&per_page=30000&footnote=y',f'wdi_data_{code}.json')])
    got={}; sources=[]
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures={pool.submit(get,url,name):key for key,url,name in jobs}
        for future in as_completed(futures):
            key=futures[future]; data, source=future.result(); got[key]=(data,source); sources.append(source)
            print('archived',key,source['bytes'],flush=True)
    country_raw=got['countries'][0][1]
    countries=[{'id':r['id'],'name':r['name'],'region':r['region']['value'],'income_level':r['incomeLevel']['value']} for r in country_raw if r['region']['id']!='NA']
    countries.sort(key=lambda x:x['id']); country_map={c['id']:c for c in countries}
    series=[]; records=[]; by={}; coverage={}
    for code,(label,unit,concept,definition) in DEFS.items():
        metadata=got[code+':metadata'][0][1][0]
        source=got[code+':data'][1]
        source_id=source['id']
        item={'id':'wdi::'+code,'label':label,'unit':unit,'definition':definition,
              'concept':concept,'source_ids':[source_id,got[code+':metadata'][1]['id']],
              'adjustment':'published_source_value','source_indicator':code,
              'source_name':metadata['name'],'source_note':metadata['sourceNote'],
              'source_organization':metadata['sourceOrganization'],
              'comparison_scope':'within_country_over_time' if code=='FP.CPI.TOTL' else 'national_context',
              'estimate_note':'Published official/compiled estimate; an empty observation-status field does not certify direct measurement.'}
        series.append(item)
        for i,r in enumerate(got[code+':data'][0][1]):
            geo=r.get('countryiso3code'); year=int(r['date'])
            if geo not in country_map or year not in YEARS: continue
            value=r.get('value'); valid=finite(value)
            row={'series_id':item['id'],'geo_id':geo,'geo_name':country_map[geo]['name'],
                 'year':year,'value':value if valid else None,'unit':unit,
                 'status':'published_estimate' if valid else 'source_missing',
                 'source_id':source_id,'native_obs_status':r.get('obs_status',''),
                 'native_footnote':r.get('footnote',''),
                 'source_record_ref':source['file']+'#/1/'+str(i)}
            records.append(row); by[(code,geo,year)]=row
        included=[r for r in records if r['series_id']==item['id']]
        coverage[item['id']]={'native_rows':len(included),'numeric':sum(finite(r['value']) for r in included),
                              'missing':sum(r['value'] is None for r in included),
                              'years_with_values':sorted({r['year'] for r in included if finite(r['value'])}),
                              'countries_with_values':len({r['geo_id'] for r in included if finite(r['value'])})}
    specs=[
       ('derived::HFCE_PC_PPP_2021','Household consumption per person, constant 2021 PPP','constant 2021 international dollars per person','consumption','NE.CON.PRVT.PP.KD','SP.POP.TOTL',1),
       ('derived::HFCE_PC_CURRENT_USD','Household consumption per person, current USD','current USD per person','consumption','NE.CON.PRVT.CD','SP.POP.TOTL',1),
       ('derived::HFCE_PC_CURRENT_LCU','Household consumption per person, current local currency','current local currency units per person','consumption','NE.CON.PRVT.CN','SP.POP.TOTL',1),
       ('derived::CPI_2021_100','Consumer price change, national 2021 = 100','index, national 2021 = 100','consumer_price_change','FP.CPI.TOTL','FP.CPI.TOTL',100),
    ]
    derived_records=[]
    for sid,label,unit,concept,numerator,denominator,scale in specs:
        is_cpi=concept=='consumer_price_change'
        definition=('National CPI rebased to 2021 = 100 using this country’s published 2021 CPI. Levels remain unsuitable for cross-country price comparisons.' if is_cpi else 'Calculated national-account consumption total divided by the same country’s population in the same year. Includes nonprofits serving households; not a median household budget or household income.')
        series.append({'id':sid,'label':label,'unit':unit,'definition':definition,'concept':concept,
           'source_ids':[got[numerator+':data'][1]['id'],got[denominator+':data'][1]['id']],
           'adjustment':'derived_same_country_CPI_rebase' if is_cpi else 'derived_same_year_per_person',
           'formula':'100 * CPI(country, year) / CPI(country, 2021)' if is_cpi else f'{numerator}(country, year) / SP.POP.TOTL(country, year)',
           'comparison_scope':'within_country_over_time' if is_cpi else 'national_account_average',
           'estimate_note':'Calculated from published estimates; no interpolation or extrapolation.'})
        for country in countries:
            for year in YEARS:
                a=by.get((numerator,country['id'],year)); b=by.get((denominator,country['id'],2021 if is_cpi else year))
                ok=a is not None and b is not None and finite(a['value']) and finite(b['value']) and b['value']>0
                row={'series_id':sid,'geo_id':country['id'],'geo_name':country['name'],'year':year,
                     'value':scale*a['value']/b['value'] if ok else None,'unit':unit,
                     'status':'calculated_adjustment' if ok else 'missing_required_input',
                     'source_id':'derived:wdi_household',
                     'source_record_refs':[x['source_record_ref'] for x in [a,b] if x],
                     'inputs':[{'series_id':x['series_id'],'year':x['year'],'value':x['value'],'source_record_ref':x['source_record_ref']} for x in [a,b] if x]}
                derived_records.append(row)
        selected=[r for r in derived_records if r['series_id']==sid]
        coverage[sid]={'rows':len(selected),'numeric':sum(finite(r['value']) for r in selected),
                       'missing':sum(r['value'] is None for r in selected),
                       'years_with_values':sorted({r['year'] for r in selected if finite(r['value'])}),
                       'countries_with_values':len({r['geo_id'] for r in selected if finite(r['value'])})}
    packet={'schema':'household-affordability.wdi-source-module/v1',
        'prepared_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'years':YEARS,
        'countries':countries,'series':series,'records':records+derived_records,
        'coverage':coverage,'sources':sorted(sources,key=lambda x:x['id']),
        'limitations':[
           'Consumption national accounts include nonprofit institutions serving households (NPISHs). Consumption is not income and per-person means do not describe a typical household or inequality.',
           'Constant 2021 PPP consumption is already price-adjusted; no U.S. GDP deflator is applied.',
           'Household-consumption price-level index compares broad national prices with United States = 100 in each year. It is not a local housing quotation, household-specific basket or minimum living-cost estimate.',
           'CPI measures within-country price change. Rebasing cannot make national CPI levels comparable price levels across countries.',
           'Blank native observation flags do not rule out source estimation. Native missing values, original flags, footnotes and source rows are retained.',
           'No interpolation, nearest-year filling, unsupported territory substitution or original-source rewriting is performed.',
           'Current local-currency consumption values require a valid country, currency and period context. They are not directly comparable across countries.',
           'PPP factor and exchange-rate sources are retained for audit; the published native PLI is used rather than a local PPP/FX substitution.'
        ]}
    (ROOT/'wdi_household_module.json').write_text(json.dumps(packet,ensure_ascii=False,separators=(',',':'),allow_nan=False))
    with (ROOT/'wdi_household_values.csv').open('w',newline='') as f:
        columns=['series_id','geo_id','geo_name','year','value','unit','status','source_id','native_obs_status','native_footnote','source_record_ref']
        writer=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore'); writer.writeheader(); writer.writerows(packet['records'])
    index={'schema':'household-affordability.wdi-source-index/v1','sources':packet['sources'],'coverage':coverage,
        'native_rows':len(records),'derived_rows':len(derived_records),'native_nonaggregate_economies':len(countries)}
    (ROOT/'WDI_SOURCE_INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2))
    paths=sorted(SOURCE.glob('wdi_*.json'))+[ROOT/'wdi_household_module.json',ROOT/'wdi_household_values.csv',ROOT/'WDI_SOURCE_INDEX.json']
    with (ROOT/'WDI_SHA256SUMS.tsv').open('w') as f:
        f.write('sha256\tbytes\tpath\n')
        for path in paths:
            raw=path.read_bytes(); f.write(f'{hashlib.sha256(raw).hexdigest()}\t{len(raw)}\t{path.relative_to(ROOT)}\n')
    print(json.dumps({'countries':len(countries),'native_rows':len(records),'derived_rows':len(derived_records),'coverage':coverage},indent=2))

if __name__=='__main__': main()
