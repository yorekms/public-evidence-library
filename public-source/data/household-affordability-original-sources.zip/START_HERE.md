# Household resources, consumption and living costs

[Open the public household explorer](https://public-evidence-library-yorek.tasty-siren-3221.chatgpt.site/#households), or [open the local economic models](http://127.0.0.1:8772/pipelines.html?view=economics) and move to the household panel below the GDP purchasing-power context. The original data catalogue, commodity maps, GDP comparisons and monetary model accounts remain available.

The explorer offers twelve measures for 2000–2025, using available source years rather than filling gaps. It contains 28,878 retained cells and survey records, including 24,432 numerical values. Coverage differs by measure; the country list is the union of 218 source economies, not a claim that every measure covers every country or year.

Read HOUSEHOLD_AFFORDABILITY.md for definitions, price bases, exact calculations, limitations and Python research examples. Read WDI_SOURCE_GUIDE.md and income_sources/SOURCE_GUIDE.md for the original-source selections and metadata. The full WDI module retains thirteen measures, including current-currency consumption totals and conversion factors beyond the four core WDI views. All raw source files and older source definitions are preserved.

Use the measure selector to inspect income, consumption, consumer price levels or inflation. Select a country and comparison country, then a reporting year. Country histories keep actual survey dates, gaps and known comparability changes. Native national currencies and CPI levels use separate country plots and are excluded from a shared international map scale.

**Download selected histories** provides CSV. **Download household evidence and model context** provides original records, source fields and adjustment inputs; the local model version also includes copies of any currently loaded original baseline/scenario. Changing household selections does not calculate a demand scenario.

The public [original-source ZIP](https://public-evidence-library-yorek.tasty-siren-3221.chatgpt.site/data/household-affordability-original-sources.zip) includes the acquisition/build scripts, source modules, original responses, metadata, source selections and independent source-readback receipts. household.json is the installed, normalized interface/research packet. HOUSEHOLD_MANIFEST.json records its exact coverage and hash.

The Python helper at workbench/household_affordability.py in the current workbench supports exact-year household context, source-attached country comparisons, guarded temporal comparisons, explicit research panels and original model evidence attachment. It does not change model coefficients or infer household outcomes from industry responses. The original local service continues running without a restart.

Verification receipts are in qa/. Source-readback checks establish faithful extraction and the documented arithmetic; they do not remove sampling error, source estimation uncertainty, survey-definition differences or omitted-variable bias.
