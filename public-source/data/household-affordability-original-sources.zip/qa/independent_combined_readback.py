"""Independent readback using archived source bytes, not builder functions."""
from pathlib import Path
import csv, hashlib, json, math
from collections import Counter
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
raw=(ROOT/'household.json').read_bytes()
packet=json.loads(raw)
failures=[]; counts=Counter()
documents={}
def check(condition, message, category):
    counts[category]+=1
    if not condition: failures.append(message)
def close(a,b):
    if a is None or b is None: return a is b
    return math.isclose(a,b,rel_tol=2e-15,abs_tol=1e-9)
def resolve(ref):
    if isinstance(ref,str):
        fn,pointer=ref.split('#')
        if fn not in documents: documents[fn]=json.loads((ROOT/fn).read_bytes())
        data=documents[fn]
        for part in pointer.strip('/').split('/'):
            data=data[int(part)] if isinstance(data,list) else data[part]
        return data
    p=ROOT/ref['file']
    if p.suffix=='.csv':
        with p.open(newline='',encoding='utf-8-sig') as f: data=list(csv.DictReader(f))
    else: data=json.loads(p.read_bytes())
    return data[ref['row_index']]

# Source-byte registers are separate from builder-derived packet contents.
windex=json.loads((ROOT/'WDI_SOURCE_INDEX.json').read_text())
for source in windex['sources']:
    b=(ROOT/source['file']).read_bytes()
    check(hashlib.sha256(b).hexdigest()==source['sha256'] and len(b)==source['bytes'],source['file'],'source_hash')
incomeindex=json.loads((ROOT/'income_sources/SOURCE_INDEX.json').read_text())
for source in incomeindex['files']:
    p=ROOT/'income_sources'/source['file']
    if not p.exists():
        check(not source.get('usable_as_source'),str(p),'source_register_presence')
        continue
    b=p.read_bytes()
    check(hashlib.sha256(b).hexdigest()==source['sha256'] and len(b)==source['bytes'],str(p),'source_hash')

with (ROOT/'income_sources/oecd_idd_income_2000plus.csv').open(newline='',encoding='utf-8-sig') as f:
    oecd=list(csv.DictReader(f))
pip=json.loads((ROOT/'income_sources/pip_20260922_2021_all_surveys.json').read_bytes())
cpi=json.loads((ROOT/'sources/wdi_data_FP.CPI.TOTL.json').read_bytes())[1]
cpimap={(r['countryiso3code'],int(r['date'])):r for r in cpi}
idx={(r['series_id'],r['geo_id'],r['year']):r for r in packet['records']}

for r in packet['records']:
    sid=r['series_id']; key=(sid,r['geo_id'],r['year'])
    if sid.startswith('pip::') or sid.startswith('oecd::'):
        ref=r['source_record_refs'][0]
        src=(pip if sid.startswith('pip::') else oecd)[ref['row_index']]
        counts['native_income_records']+=1
        check(r['source_record']==src,str(key)+' full source','income_native_full_row')
        check(r['value']==float(src[ref['value_field']]),str(key)+' value','income_native_value')
        if sid.startswith('pip::'):
            check(r['geo_id']==src['country_code'] and r['year']==src['reporting_year'] and r['source_year']==src['survey_year'],str(key)+' native country/year','income_native_period')
            check(r['welfare_type']==src['welfare_type'] and src['reporting_level']=='national' and src['survey_coverage']=='national' and src['is_interpolated'] is False,str(key)+' welfare/coverage','income_native_concept')
        else:
            check(r['geo_id']==src['REF_AREA'] and str(r['year'])==src['TIME_PERIOD'] and r['currency']==src['CURRENCY'],str(key)+' native country/year/currency','income_native_period')
        check(r['source_record_ref']==ref,str(key)+' singular/plural ref','income_ref_normalization')
    if sid in ['wdi::PA.NUS.PRVT.PLI','wdi::FP.CPI.TOTL']:
        src=resolve(r['source_record_refs'][0])
        check(r['geo_id']==src['countryiso3code'] and str(r['year'])==src['date'] and r['value']==src['value'] and r['native_obs_status']==src.get('obs_status','') and r['native_footnote']==src.get('footnote',''),str(key)+' native WDI record','WDI_native_value_period_status')
    if sid in ['derived::HFCE_PC_PPP_2021','derived::CPI_2021_100']:
        left,right=[resolve(ref) for ref in r['source_record_refs']]
        base=2021 if sid=='derived::CPI_2021_100' else r['year']
        scale=100 if sid=='derived::CPI_2021_100' else 1
        valid=left['value'] is not None and right['value'] is not None and right['value']>0
        expected=left['value']/right['value']*scale if valid else None
        check(left['countryiso3code']==right['countryiso3code']==r['geo_id'] and int(left['date'])==r['year'] and int(right['date'])==base,str(key)+' raw derivation periods','WDI_derived_input_periods')
        check(close(r['value'],expected),str(key)+' raw-derived value','WDI_derived_value')
    if sid.startswith('derived::OECD_'):
        counts['OECD_adjusted_records']+=1
        refs=r['source_record_refs']
        src=oecd[refs[0]['row_index']]
        current=cpimap[(r['geo_id'],r['year'])]
        base=cpimap[(r['geo_id'],2021)]
        valid=current['value'] is not None and base['value'] is not None and current['value']>0 and base['value']>0
        expected=float(src['OBS_VALUE'])*base['value']/current['value'] if valid else None
        check(close(r['value'],expected) and r['eligible']==valid,str(key)+' raw OECD/CPI result','OECD_adjusted_formula')
        check(r['original_income']==float(src['OBS_VALUE']) and r['currency']==src['CURRENCY'] and r['base_year']==2021,str(key)+' original/currency/base','OECD_adjusted_original')
        check(len(r['inputs'])==3 and len(refs)==3,str(key)+' exactly three inputs/refs','OECD_adjusted_input_count')
        check(resolve(refs[1])==current and resolve(refs[2])==base,str(key)+' raw CPI refs','OECD_adjusted_CPI_refs')
        check(r['inputs'][0]['value']==float(src['OBS_VALUE']) and r['inputs'][0]['currency']==src['CURRENCY'] and r['inputs'][0]['source_record_refs']==[refs[0]],str(key)+' original input','OECD_adjusted_income_input')
        for value,year,pos in [(current['value'],r['year'],1),(base['value'],2021,2)]:
            check(r['inputs'][pos]['value']==value and r['inputs'][pos]['year']==year and r['inputs'][pos]['source_record_ref']==refs[pos],str(key)+' CPI input '+str(pos),'OECD_adjusted_CPI_inputs')
        native=idx[(r['original_income_series_id'],r['geo_id'],r['year'])]
        check(r['comparability_group']==native['comparability_group'] and src['METHODOLOGY'] in r['comparability_group'] and src['DEFINITION'] in r['comparability_group'] and src['CURRENCY'] in r['comparability_group'],str(key)+' currency/method group','OECD_adjusted_comparability')
        counts['OECD_unavailable_inputs']+=not valid

for s in packet['series']:
    if s['id'].startswith('oecd::') or s['id'].startswith('derived::OECD_') or s['id'] in ['wdi::FP.CPI.TOTL','derived::CPI_2021_100']:
        check(s['cross_country_eligible'] is False,s['id']+' cross-country restriction','comparison_flags')
    if s['id'].startswith('pip::') or s['id'].startswith('oecd::') or s['id'].startswith('derived::OECD_'):
        check(s['requires_comparability_group'] is True,s['id']+' comparability required','comparison_flags')
keys=[(r['series_id'],r['geo_id'],r['year']) for r in packet['records']]
check(len(keys)==len(set(keys)),'duplicate normalized keys','row_accounting')
check(packet['coverage']['records']==len(packet['records']),'packet total rows','row_accounting')
for module in packet['methods']['source_modules']:
    check(hashlib.sha256((ROOT/module['file']).read_bytes()).hexdigest()==module['sha256'],module['file']+' source-module hash','source_module_hash')

receipt={'schema':'household-affordability.combined-independent-source-readback/v1',
 'checked_utc':datetime.now(timezone.utc).isoformat(),'packet_sha256':hashlib.sha256(raw).hexdigest(),'packet_bytes':len(raw),
 'packet_records':len(packet['records']),'checks':dict(counts),'failures':failures,
 'scope':'Direct archived CSV/PIP/WDI raw-byte record readback and independent household formula calculations; no builder functions imported or invoked.'}
(ROOT/'qa/COMBINED_INDEPENDENT_READBACK.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
if failures:raise SystemExit(1)
