# Household income and survey consumption: retained official sources

This companion adds household measures without relabeling GDP or GNI as household income. It retains the exact downloaded source files, their native records, the selection ledger and normalized research records. The two source families have different units and populations; keep those distinctions visible in figures and models.

## OECD: annual equivalised disposable household income

The [OECD Income Distribution Database](https://www.oecd.org/en/data/datasets/income-and-wealth-distribution-database.html) supplies annual mean and median disposable household income in **current national currency per equivalent household member**. Household income is adjusted by the square root of household size and attributed to the household's members. A four-person household's income is divided by two for this equivalence measure. It is therefore different from income per person and from total income per household.

Disposable income includes employment, self-employment and capital income and cash transfers, after relevant direct taxes and social contributions. The full component definitions and source conventions are retained in `oecd_idd_terms_2012.pdf`; the [official terms of reference](https://www.oecd.org/content/dam/oecd/en/data/datasets/income-and-wealth-distribution-databases/idd-tor-2012-onwards.pdf) provide the detailed definitions. It is not GDP per person, gross wages or a direct measurement of the cost of necessities.

The original CSV contains **1,952 records** for mean and median, all ages, 2000 onwards, including overlapping methods and previous definitions. The selected packet contains **1,224 records across 45 countries, 2000–2025**, using only `METH2012` (income definition since 2012) and `D_CUR` (current definition). The methodology label concerns how income is defined; selected historical observations can precede 2012. Older methods and earlier definitions remain in the original CSV and the exclusion ledger. They are not silently joined to the selected series.

The native unit is `XDC_HH_EQ`; the native price code is `V` (current prices), and each row retains its currency code. **These values are nominal and cannot be ranked across different currencies as though they shared one unit.** Country-specific consumer-price adjustment and a suitable household-consumption PPP basis are required to create a separate cross-country/constant-price reporting view. No such conversion is applied in this source packet.

Of the selected rows, 1,222 have OECD status `A` (normal value) and two have `P` (provisional value). The latter are the Netherlands' 2024 mean and median. A normal-value source flag does not remove survey sampling, coverage or harmonization uncertainty. Native decimal settings, currency, status, methodology and definition are preserved in every referenced source row.

## World Bank PIP: mean and median household welfare in 2021 PPP

The [Poverty and Inequality Platform](https://pip.worldbank.org/about) publishes household survey estimates of income or consumption. The retained query freezes **`20260922_2021_01_02_PROD`**, rather than silently refreshing to the API's future default. The available-version response and computational package information are archived with the data.

The PIP data dictionary defines mean and median as the average and middle value, respectively, of **daily household income or consumption expenditure per capita, expressed in 2021 PPP**. These native published values have already been adjusted by the source. No additional deflation, PPP conversion, population division or annualization is applied here.

The source's `welfare_type` is retained and split into four separate series:

| Series | Meaning | Unit |
| --- | --- | --- |
| PIP income median | Median household income per person | 2021 PPP international dollars per person per day |
| PIP income mean | Mean household income per person | Same |
| PIP consumption median | Median household consumption expenditure per person | Same |
| PIP consumption mean | Mean household consumption expenditure per person | Same |

The original frozen response has **2,588 rows** across its full time range and reporting levels. The selected 2000–2025 national sample contains **1,931 survey rows across 168 countries**: 1,161 income survey rows in 70 countries and 770 consumption survey rows in 121 countries. Mean and median are complete for these selected survey rows, producing 3,862 metric records. Some countries have both welfare types in their histories; they remain separate, with no income-to-consumption substitution.

All selected rows have `reporting_level=national`, `survey_coverage=national`, `estimation_type=survey` and `is_interpolated=false`. The request uses `fill_gaps=false`. A year without a survey remains unavailable. Published survey estimates are not exact observations of every household or an assurance of universal comparability.

### Preserve survey periods and comparability breaks

Use native **`reporting_year`** for the annual view and retain exact **`survey_year`** for display and research. The source includes 210 fractional survey-year values. In Tanzania, the native reporting year is 2018 while the survey year is 2017.92; simply flooring the latter would change the source's period assignment. Both are preserved in the packet.

`survey_comparability` and `comparable_spell` identify source-defined temporal segments. The dictionary says the comparability code changes when a series break occurs. The normalized `comparability_group` includes country, welfare type, code and spell. A time trend should stay within one such segment unless the researcher explicitly addresses the break. A shared numeric comparability code in two countries does not imply identical questionnaires, welfare definitions or baskets.

PIP maximizes harmonization, but differences in survey design, income/consumption coverage, household composition, regional price treatment and data availability remain. Use the [current methodology handbook](https://datanalytics.worldbank.org/PIP-Methodology/) when designing an analysis. Its index and official survey-estimation source text are archived here. The [PIP API client reproducibility guide](https://worldbank.github.io/pipr/articles/reproducible-research.html) explains the version and computational-package metadata.

## Research and display boundaries

- Keep median and mean separate. Their gap can be informative about a distribution; neither replaces the other.
- Keep OECD equivalised disposable income separate from PIP per-capita welfare, even after price conversion. A shared currency basis does not make their denominators or income definitions identical.
- Use the exact requested year when joining to economic accounts. A nearby survey year can be shown as separately dated context, with an explicit lag, but should not silently fill the model year.
- PIP consumption is a household survey welfare measure. National-accounts household consumption, which may include nonprofit institutions serving households, is a separate source and concept.
- Relative consumer price levels and CPI are useful affordability context. They do not establish what a particular family must spend on housing, food, transport, health or taxes.
- No household response to a modeled output shock is inferred from these records. Scenario-to-household transmission needs its own explicit assumptions and evidence.

## Files and provenance

`income_packet.json` contains six series and 5,086 normalized metric records. Each record retains the full native source row and a zero-based source-row reference. `income_records.csv` is a flat research export. `EXCLUSION_LEDGER.csv` accounts for every original row excluded from the selected normalized view, without deleting it from the original download.

`SOURCE_INDEX.json` records exact URLs, file sizes, SHA-256 hashes and HTTP statuses. Three unsuccessful documentation fetches are retained as failed attempts and marked unusable as sources. The successful OECD PDF, SDMX structure, PIP dictionary and current methodology files provide the retained definitions. The raw PIP dictionary response contains Latin-1 bytes; its exact response is preserved and decoding occurs only in the normalized packet.

`INDEPENDENT_SOURCE_READBACK.json` records the native-row and value checks. `SHA256SUMS.tsv` covers the source and generated companion files. `build_income_packet.py` rebuilds the packet from these retained bytes without refreshing sources or modifying any existing workbench collection.
