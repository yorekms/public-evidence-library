"""Build an additive household-income companion from retained official source bytes.

No existing workbench file is opened for writing. Re-running this script uses the
retained source downloads; it does not silently refresh the data vintage.
"""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parent
PIP_VERSION = "20260922_2021_01_02_PROD"
PIP_FILE = "pip_20260922_2021_all_surveys.json"
OECD_FILE = "oecd_idd_income_2000plus.csv"

SOURCE_REQUESTS = [
    ("pip_versioned_surveys", PIP_FILE, "https://api.worldbank.org/pip/v1/pip?country=all&year=all&povline=3&fill_gaps=false&welfare_type=all&reporting_level=all&version=20260922_2021_01_02_PROD&format=json", 200),
    ("pip_default_audit", "pip_all_surveys.json", "https://api.worldbank.org/pip/v1/pip?country=all&year=all&poverty_line=3.00&fill_gaps=false&format=json", 200),
    ("pip_versions", "pip_versions.json", "https://api.worldbank.org/pip/v1/versions", 200),
    ("pip_info", "pip_info.json", "https://api.worldbank.org/pip/v1/pip-info", 200),
    ("pip_dictionary", "pip_dictionary.json", "https://api.worldbank.org/pip/v1/aux?table=dictionary&format=json", 200),
    ("pip_methodology", "pip_methodology_current.html", "https://datanalytics.worldbank.org/PIP-Methodology/", 200),
    ("pip_survey_method_source", "pip_calculating_survey_estimates.Rmd", "https://raw.githubusercontent.com/worldbank/PIP-Methodology/master/04-Calculating-survey-estimates.Rmd", 200),
    ("oecd_income", OECD_FILE, "https://sdmx.oecd.org/public/rest/v1/data/OECD.WISE.INE,DSD_WISE_IDD@DF_IDD,1.0/.A.INC_DISP.MEAN+MEDIAN.._T...?startPeriod=2000&format=csvfile", 200),
    ("oecd_structure", "oecd_idd_structure.xml", "https://sdmx.oecd.org/public/rest/v1/dataflow/OECD.WISE.INE/DSD_WISE_IDD@DF_IDD/1.0?references=all", 200),
    ("oecd_terms", "oecd_idd_terms_2012.pdf", "https://www.oecd.org/content/dam/oecd/en/data/datasets/income-and-wealth-distribution-databases/idd-tor-2012-onwards.pdf", 200),
    ("failed_oecd_landing_fetch", "oecd_idd_methodology.html", "https://www.oecd.org/en/data/datasets/income-and-wealth-distribution-databases.html", 403),
    ("failed_old_pip_acquiring", "pip_methodology_acquiring.html", "https://worldbank.github.io/PIP-Methodology/acquiring.html", 404),
    ("failed_old_pip_survey", "pip_methodology_survey_estimates.html", "https://worldbank.github.io/PIP-Methodology/surveyestimates.html", 404),
]


def dump(name, obj):
    (ROOT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


def main():
    ns = {"s": "http://www.sdmx.org/resources/sdmxml/schemas/v2_1/structure", "c": "http://www.sdmx.org/resources/sdmxml/schemas/v2_1/common"}
    xml = ET.parse(ROOT / "oecd_idd_structure.xml").getroot()
    labels = {}
    for cl in xml.findall(".//s:Codelist", ns):
        labels[cl.attrib["id"]] = {
            code.attrib["id"]: next((name.text for name in code.findall("c:Name", ns)
                                      if name.attrib.get("{http://www.w3.org/XML/1998/namespace}lang") == "en"), code.attrib["id"])
            for code in cl.findall("s:Code", ns)
        }
    pip = json.loads((ROOT / PIP_FILE).read_bytes())
    original_pip = json.loads((ROOT / "pip_all_surveys.json").read_bytes())
    assert pip == original_pip, "The default audit download differs from the frozen version"
    versions = json.loads((ROOT / "pip_versions.json").read_bytes())
    assert any(v["version"] == PIP_VERSION and v["ppp_version"] == "2021" for v in versions)
    dictionary = json.loads((ROOT / "pip_dictionary.json").read_text(encoding="latin1"))
    definitions = {x["variable"]: x["definition"] for x in dictionary}
    assert "2021 PPP" in definitions["mean"] and "2021 PPP" in definitions["median"]
    with (ROOT / OECD_FILE).open(newline="") as f:
        oecd = list(csv.DictReader(f))
    records, exclusions, series = [], [], []
    for welfare in ("income", "consumption"):
        for statistic in ("median", "mean"):
            series.append({
                "id": f"pip::{welfare}::{statistic}_2021ppp_daily",
                "name": f"Survey {statistic} household {welfare} per person",
                "family": f"survey_{welfare}", "statistic": statistic,
                "definition": definitions[statistic],
                "unit": "2021 PPP international dollars per person per day",
                "price_basis": "constant 2021 PPP; already adjusted by source",
                "source_id": "worldbank_pip_20260922_2021", "source_adjusted": True,
                "cross_country_comparison": "Qualified: same welfare type, source harmonization limits retained",
                "temporal_comparison": "Survey years only; compare within the same country/welfare/comparability spell",
                "interpolation": False,
            })
    for statistic in ("median", "mean"):
        series.append({
            "id": f"oecd::IDD::{statistic}_disposable_native",
            "name": f"{statistic.capitalize()} equivalised disposable household income",
            "family": "disposable_income", "statistic": statistic,
            "definition": "Annual disposable household income, equivalised by the square root of household size and attributed to household members; entire population. Current definition, income methodology since 2012.",
            "unit": "national currency per equivalent household member per year",
            "price_basis": "current national-currency prices; currency code retained per record",
            "source_id": "oecd_idd_20261031", "source_adjusted": False,
            "cross_country_comparison": "Not directly comparable across currencies; no PPP conversion applied locally",
            "temporal_comparison": "Nominal only until country-specific price adjustment; current definition and METH2012 retained separately from older methods",
            "interpolation": False,
        })
    selected_pip = []
    for index, row in enumerate(pip):
        reason = None
        if row["reporting_level"] != "national": reason = "subnational reporting level"
        elif not 2000 <= row["reporting_year"] <= 2025: reason = "outside selected 2000–2025 reporting years"
        elif row["is_interpolated"]: reason = "interpolated record"
        elif row["estimation_type"] != "survey": reason = "not a survey estimate"
        if reason:
            exclusions.append({"source_file": PIP_FILE, "row_index": index, "reason": reason})
            continue
        selected_pip.append(row)
        for statistic in ("median", "mean"):
            value = row[statistic]
            records.append({
                "series_id": f"pip::{row['welfare_type']}::{statistic}_2021ppp_daily",
                "geo_id": row["country_code"], "geo_name": row["country_name"],
                "year": row["reporting_year"], "source_year": row["survey_year"],
                "value": value, "unit": "2021 PPP international dollars per person per day",
                "status": "published_survey_estimate_source_adjusted",
                "status_label": "Published survey estimate, adjusted by source to 2021 PPP",
                "estimate": True, "derived_locally": False, "source_adjusted": True,
                "source_id": "worldbank_pip_20260922_2021",
                "source_record_ref": {"file": PIP_FILE, "row_index": index, "value_field": statistic},
                "source_record": row, "welfare_type": row["welfare_type"],
                "statistic": statistic, "reporting_level": row["reporting_level"],
                "survey_acronym": row["survey_acronym"],
                "survey_comparability": row["survey_comparability"], "comparable_spell": row["comparable_spell"],
                "comparability_group": f"PIP::{row['country_code']}::{row['welfare_type']}::{row['survey_comparability']}::{row['comparable_spell']}",
                "is_interpolated": row["is_interpolated"], "native_estimation_type": row["estimation_type"],
                "native_distribution_type": row["distribution_type"],
            })
    selected_oecd = []
    for index, row in enumerate(oecd):
        reason = None
        if row["DEFINITION"] != "D_CUR": reason = "previous definition retained only in original source"
        elif row["METHODOLOGY"] != "METH2012": reason = "earlier income methodology retained only in original source"
        elif not 2000 <= int(row["TIME_PERIOD"]) <= 2025: reason = "outside selected years"
        if reason:
            exclusions.append({"source_file": OECD_FILE, "row_index": index, "reason": reason})
            continue
        assert row["UNIT_MEASURE"] == "XDC_HH_EQ" and row["AGE"] == "_T"
        assert row["PRICE_BASE"] == "V" and row["UNIT_MULT"] in ("", "0")
        selected_oecd.append(row)
        statistic = row["STATISTICAL_OPERATION"].lower()
        records.append({
            "series_id": f"oecd::IDD::{statistic}_disposable_native",
            "geo_id": row["REF_AREA"], "geo_name": labels["CL_AREA"].get(row["REF_AREA"], row["REF_AREA"]),
            "year": int(row["TIME_PERIOD"]), "source_year": int(row["TIME_PERIOD"]),
            "value": float(row["OBS_VALUE"]) if row["OBS_VALUE"] else None,
            "unit": f"{row['CURRENCY']} per equivalent household member per year (current prices)",
            "currency": row["CURRENCY"], "status": "published_household_income_estimate",
            "status_label": "Published household-income estimate" + ("; provisional" if row["OBS_STATUS"] == "P" else ""),
            "estimate": True, "derived_locally": False, "source_adjusted": False,
            "source_id": "oecd_idd_20261031", "source_record_ref": {"file": OECD_FILE, "row_index": index, "value_field": "OBS_VALUE"},
            "source_record": row, "statistic": statistic, "native_obs_status": row["OBS_STATUS"],
            "native_obs_status_label": labels["CL_OBS_STATUS"].get(row["OBS_STATUS"], row["OBS_STATUS"]),
            "methodology": row["METHODOLOGY"], "definition": row["DEFINITION"],
            "comparability_group": f"OECD::IDD::{row['REF_AREA']}::{row['METHODOLOGY']}::{row['DEFINITION']}::{row['CURRENCY']}",
            "cross_country_comparable_without_adjustment": False,
        })
    keys = Counter((r["series_id"], r["geo_id"], r["year"]) for r in records)
    duplicates = [{"key": key, "count": count} for key, count in keys.items() if count > 1]
    assert not duplicates
    files = []
    for source_id, filename, url, status in SOURCE_REQUESTS:
        path = ROOT / filename
        data = path.read_bytes()
        files.append({"id": source_id, "file": filename, "url": url, "http_status": status,
                      "usable_as_source": status == 200, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                      "retained_file_timestamp_utc": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat()})
    coverage = {
        "selected_years": [2000, 2025], "all_normalized_records": len(records),
        "pip_version": PIP_VERSION, "pip_raw_rows": len(pip), "pip_national_survey_rows_selected": len(selected_pip),
        "pip_selected_countries": len({r["country_code"] for r in selected_pip}),
        "pip_income_survey_rows": sum(r["welfare_type"] == "income" for r in selected_pip),
        "pip_income_countries": len({r["country_code"] for r in selected_pip if r["welfare_type"] == "income"}),
        "pip_consumption_survey_rows": sum(r["welfare_type"] == "consumption" for r in selected_pip),
        "pip_consumption_countries": len({r["country_code"] for r in selected_pip if r["welfare_type"] == "consumption"}),
        "pip_fractional_source_years": sum(r["survey_year"] != r["reporting_year"] for r in selected_pip),
        "pip_source_year_floor_mismatches": [{k:r[k] for k in ("country_code", "reporting_year", "survey_year", "welfare_type")} for r in selected_pip if int(r["survey_year"]) != r["reporting_year"]],
        "pip_missing_mean_or_median": sum(r[f] is None for r in selected_pip for f in ("mean", "median")),
        "oecd_raw_rows": len(oecd), "oecd_current_method_current_definition_rows": len(selected_oecd),
        "oecd_selected_countries": len({r["REF_AREA"] for r in selected_oecd}),
        "oecd_native_statuses": dict(Counter(r["OBS_STATUS"] for r in selected_oecd)),
        "duplicate_series_country_year_keys": duplicates,
        "exclusion_reasons": dict(Counter(r["reason"] for r in exclusions)),
    }
    packet = {
        "schema": "household-affordability.income-sources/v1", "prepared_utc": datetime.now(timezone.utc).isoformat(),
        "series": series, "records": records, "coverage": coverage,
        "sources": [
            {"id": "worldbank_pip_20260922_2021", "name": "World Bank Poverty and Inequality Platform", "version": PIP_VERSION,
             "url": files[0]["url"], "file": PIP_FILE, "sha256": files[0]["sha256"],
             "method_url": "https://datanalytics.worldbank.org/PIP-Methodology/", "price_basis": "constant 2021 PPP"},
            {"id": "oecd_idd_20261031", "name": "OECD Income Distribution Database", "version": "DSD_WISE_IDD@DF_IDD,1.0; retrieved 2026-10-31",
             "url": next(f["url"] for f in files if f["id"] == "oecd_income"), "file": OECD_FILE,
             "sha256": next(f["sha256"] for f in files if f["id"] == "oecd_income"),
             "method_url": "https://www.oecd.org/content/dam/oecd/en/data/datasets/income-and-wealth-distribution-databases/idd-tor-2012-onwards.pdf",
             "price_basis": "current national-currency prices"},
        ],
        "limitations": [
            "PIP income and consumption are distinct welfare measures and must not be silently combined into a single income series.",
            "PIP mean and median are daily household welfare per capita, while OECD income is annual equivalised disposable income; their denominators and definitions differ.",
            "PIP values have already been CPI/PPP adjusted by the source. No local inflation or PPP conversion is applied.",
            "All PIP displayed rows are national survey estimates with fill_gaps=false and is_interpolated=false. Missing annual survey data remain unavailable.",
            "Use native reporting_year for annual views and preserve exact survey_year. Tanzania's 2018 reporting year has survey_year 2017.92; flooring would silently change its source period.",
            "A PIP comparable_spell and survey_comparability code identify a source-defined series segment, not universal cross-country equivalence. Do not fit a continuous temporal trend across a break without an explicit research decision.",
            "OECD current-definition METH2012 rows are selected without stitching to older methods. Earlier/previous definitions remain available in the original CSV and exclusion ledger.",
            "OECD national-currency income values are nominal and require country-specific CPI and suitable consumption PPP/currency checks for comparable real purchasing-power reporting.",
            "The OECD normal-value flag is not a claim that survey uncertainty is absent. Provisional flags remain explicit.",
            "Neither source is a quoted household necessities basket or a complete household affordability budget; housing, wealth, public services and household composition remain relevant.",
        ],
        "codelists": {k: labels[k] for k in ("CL_METHODOLOGY", "CL_DEFINITION", "CL_OBS_STATUS")},
        "pip_dictionary": dictionary,
        "raw_file_register": "SOURCE_INDEX.json", "exclusions": "EXCLUSION_LEDGER.csv",
    }
    dump("income_packet.json", packet)
    dump("SOURCE_INDEX.json", {"retrieval_date": "2026-10-31", "files": files, "dictionary_decode": "Raw dictionary response uses Latin-1 bytes; source retained exactly; decoded only for normalized JSON."})
    dump("COVERAGE.json", coverage)
    with (ROOT / "EXCLUSION_LEDGER.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["source_file", "row_index", "reason"]); writer.writeheader(); writer.writerows(exclusions)
    with (ROOT / "income_records.csv").open("w", newline="") as f:
        fields = ["series_id", "geo_id", "geo_name", "year", "source_year", "value", "unit", "status", "source_id", "comparability_group", "currency", "welfare_type", "survey_acronym", "survey_comparability", "comparable_spell", "native_obs_status"]
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore"); writer.writeheader(); writer.writerows(records)
    # Independent readback: every normalized value and native record must equal
    # the referenced original source row, including source-year distinctions.
    checks = 0
    for record in json.loads((ROOT / "income_packet.json").read_text())["records"]:
        ref = record["source_record_ref"]
        source = pip if ref["file"] == PIP_FILE else oecd
        row = source[ref["row_index"]]
        assert row == record["source_record"]
        expected = row[ref["value_field"]]
        assert record["value"] == (float(expected) if ref["file"] == OECD_FILE and expected != "" else expected)
        checks += 2
    for retained in json.loads((ROOT / "SOURCE_INDEX.json").read_text())["files"]:
        source_bytes = (ROOT / retained["file"]).read_bytes()
        assert len(source_bytes) == retained["bytes"]
        assert hashlib.sha256(source_bytes).hexdigest() == retained["sha256"]
    dump("INDEPENDENT_SOURCE_READBACK.json", {"native_record_and_value_checks": checks, "normalized_records": len(records), "duplicate_keys": 0, "frozen_pip_equals_default_audit": True, "raw_source_hashes_verified": len(files), "failures": []})
    checksums = []
    for path in sorted(ROOT.iterdir()):
        if path.is_file() and path.name != "SHA256SUMS.tsv":
            data = path.read_bytes(); checksums.append(f"{hashlib.sha256(data).hexdigest()}\t{len(data)}\t{path.name}")
    (ROOT / "SHA256SUMS.tsv").write_text("sha256\tbytes\tpath\n" + "\n".join(checksums) + "\n")
    print(json.dumps(coverage, indent=2))


if __name__ == "__main__":
    main()
