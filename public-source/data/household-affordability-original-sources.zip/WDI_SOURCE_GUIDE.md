# Household consumption and consumer price sources

This module is an additive source companion. It retains nine native World Development Indicators (WDI) series for 217 nonaggregate economies, 2000–2025, and four explicitly calculated series. It does not rewrite any existing workbench or model inputs. Source vintage is 8 October 2026; original API response bytes, source metadata, status flags and footnotes are archived under `sources/`.

## What can be compared

**Household consumption per person at constant 2021 PPP prices** is calculated as the World Bank's published household-and-NPISH final-consumption total, `NE.CON.PRVT.PP.KD`, divided by the same economy's `SP.POP.TOTL` population estimate in the same year. Both exact input references are attached to every calculated row. The source total is already in constant 2021 international dollars; there is no further U.S. deflator or PPP conversion. This series has 4,025 numerical values across 176 economies. It describes a national-account average that includes nonprofit institutions serving households (NPISHs), rather than median household consumption, disposable income or an individual spending budget. Sources: [World Bank household consumption at constant PPP prices](https://data.worldbank.org/indicator/NE.CON.PRVT.PP.KD) and [population](https://data.worldbank.org/indicator/SP.POP.TOTL).

**Relative household-consumption price levels** use the native published `PA.NUS.PRVT.PLI` series, with the United States equal to 100 in each year. The 4,853 available values span 208 economies. This is the spatial comparison relevant to broad consumer price levels. Differences can reflect prices and exchange rates; the index does not supply a town's rent, a household-specific basket or a minimum living-cost budget. Its national scope also conceals local variation. The published series is used directly, rather than substituting a locally calculated ratio when values are missing. Source: [World Bank household consumption price-level index](https://data.worldbank.org/indicator/PA.NUS.PRVT.PLI).

**Consumer price change within a country** retains the native `FP.CPI.TOTL` index, national 2010 = 100. A derived series rebases it using `100 × CPI(country, year) / CPI(country, 2021)`, only where both native values exist and the denominator is positive. Country-specific CPI indexes describe temporal change; rebasing them does not make their index levels suitable for ranking price levels across countries. Source: [World Bank/IMF consumer price index](https://data.worldbank.org/indicator/FP.CPI.TOTL).

## Originals and supporting series

The packet also retains household consumption in [current local currency](https://data.worldbank.org/indicator/NE.CON.PRVT.CN), [current U.S. dollars](https://data.worldbank.org/indicator/NE.CON.PRVT.CD), and published [constant 2015 U.S. dollars per person](https://data.worldbank.org/indicator/NE.CON.PRVT.PC.KD). Local-currency totals are not comparable across different currencies. The constant-2015-dollar series has a different price/currency basis from the constant-2021-PPP series, and is labeled separately.

The [household-consumption PPP conversion factor](https://data.worldbank.org/indicator/PA.NUS.PRVT.PP) and [official annual-average exchange rate](https://data.worldbank.org/indicator/PA.NUS.FCRF) are retained for audit. They are not applied to industry accounts or physical commodity flows. Native PPP footnotes distinguish benchmark, Eurostat–OECD annual, ICP time-series, imputed, interpolated, extrapolated and experimental observations. Annual series do not imply that each economy conducted a new international benchmark price survey every year.

## Estimation, missingness and preservation

Published statistical-account values are labeled `published_estimate`; an empty native observation-status field does not certify direct measurement. Exact original flags and footnotes remain attached. Per-person calculations and CPI rebasing are labeled `calculated_adjustment`. Unavailable original cells remain `source_missing`; missing required inputs produce `missing_required_input`. No interpolation, nearest-year filling or territory substitution is performed.

The native observations contain 50,778 country-year-series cells. The four derived series contain 22,568 cells. Source totals, per-person averages, relative price levels and within-country CPI indexes remain distinct concepts and units. Consumption and income should not be subtracted or ratioed merely because their numerical currency labels resemble one another: coverage, sector, household definition, equivalence scale and price basis must match.

## Files and verification

- `wdi_household_module.json`: normalized records, series definitions, source references, limitations and coverage.
- `wdi_household_values.csv`: a flat export of original and calculated values with status labels. The JSON retains the full input-reference lists for calculated rows.
- `WDI_SOURCE_INDEX.json` and `WDI_SHA256SUMS.tsv`: original response locations, exact URLs, byte sizes, hashes and series coverage.
- `scripts/acquire_wdi_household.py`: reproducible acquisition and normalization; existing raw responses are reused to retain the snapshot.
- `qa/WDI_INDEPENDENT_READBACK.json`: independent native-field and calculation readback.

Readback verified all 19 original response hashes, 253,890 native value/identity/status/footnote fields and 22,568 calculated results with both input references. All 26 available U.S. price-level anchors equal 100; all 178 available country CPI rebasing anchors equal 100 in 2021. No failures or duplicate native keys were found. These checks verify extraction and calculation, rather than an independent audit of the underlying national statistical systems.
