China, Argentina and Chile | Lithium carbonate trade, 2020–2025
Source retrieval date 27 November 2026.

china_origins.csv gives WITS published China imports of HS 283691, converted from kg to tonnes. Other origins is a residual. Each share uses the world total in the same WITS table. The WITS trade-value column in the evidence extract is in thousands of current USD. WITS republishes Comtrade with its own display precision. They represent the same reporting stream.

bilateral_comparison.csv joins national exports (Argentina INDEC net tonnes or Chile COCHILCO metric tonnes), the exporter and importer records in UN Comtrade (net tonnes), and the WITS quantity in tonnes. COCHILCO does not specify a net or gross basis in this export table. The gap is national exports less the imports declared by China. Blank national quantities in 2021 and 2022 mean INDEC withheld the Argentina–China weight. Blanks in the UN exporter series represent missing records. For the precise China import weights use the China-reported UN series.

argentina_monthly_2024.csv transcribes the 12 China rows of the INDEC monthly NCM 28369100 query, partner code 310. January is flagged isConfidential. Its API placeholder zeros are recorded as missing weight and value. The eleven numeric months sum to 47,609,122 kg and USD 406,031,369.05 FOB. The public UN annual exporter record gives 47,609,120 kg and the same FOB value to the cent. INDEC's annual destination publication gives 49,989,122 kg and USD 434,853,587.85. This arithmetic does not establish how UN Comtrade compiled the annual record or the contents of a confidential cell.

sources.csv contains retrieval links for each WITS year, the INDEC query, two industry publications citing Chinese customs and Chile’s bilateral fact sheet. Secondary checks are preserved at their published precision. The SUBREI value covers one Chilean tariff line alone. The China customs portal's underlying extract was not obtained directly.

Previously archived national and UN sources
Argentina national archive and complete annual queries: https://drive.google.com/file/d/1oDRUy7UusPQDS3NnRNryMwDxGX-upcWa/view
UN trade responses for Argentina, Chile and foreign importers: https://drive.google.com/file/d/1ZZCOvILz1pxQH2usM-SL7895FwUN8aJo/view
Chile COCHILCO workbook and original destination rows: https://drive.google.com/file/d/19UVSPFMM0cANzH2wfcx0dj4mSw1NaTXL/view
