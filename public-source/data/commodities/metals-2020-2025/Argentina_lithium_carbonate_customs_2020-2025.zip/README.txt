Argentina | Lithium carbonate exports, 2020–2025
World Commodity Graphic Data • Snapshot 26 November 2026

Scope and units
INDEC annual exports, product NCM 28369100 (lithium carbonate). Figures describe product net weight in metric tonnes and free-on-board value in current US dollars. The source publishes net kilograms to three decimals. One tonne equals 1,000 kg.

How to reproduce annual.csv
Download the six annual archives listed in source_manifest.json. Filter the product-priority expona file to NCM 28369100. For each year, add numeric weights on named destinations and destination code 999 once. Divide kg by 1,000. Sum numeric FOB values by the same procedure. Each annual sum agrees with the corresponding INDEC total-export query to 0.001 kg and USD 0.01. confidential_share is the code 999 weight divided by total product weight. The named weight may be zero when every named destination is withheld. For 2021 and 2022, exporters shipped to the named destinations listed but INDEC withheld each individual weight.

How to interpret destinations.csv
The INDEC country code and original Spanish label come from the annual file and matching all-countries query. ISO2 is omitted for 999. A blank numeric value with 'Withheld (s)' indicates a shipment occurred. Use only named destinations with published weights for a weighted route map. Code 999 has no geographic position. Preserve suppressed rows for presence-only displays. The destination-priority expopa files repeat the named rows and omit 999 for this product. Do not combine the two tables. The query returns zero placeholders for some confidential rows. The isConfidential flag and the original CSV 's' take precedence. A band s1–s10 refers to FOB value only. Definitions in USD thousands are in the included INDEC guides.

Comtrade comparison
The HS 283691 exporter-world series and the sum of available foreign-reporter imports are the two series from the project's earlier packet. Coverage and reference perspectives differ. The blank world-export records for 2021 and 2022 are preserved. Amounts from separate reporting systems are never added. The difference is arithmetic and does not establish the cause of discrepancies. Reference packet including original UN responses and code definitions:
https://drive.google.com/file/d/1ZZCOvILz1pxQH2usM-SL7895FwUN8aJo/view?usp=drivesdk

Audit files
extracts/ contains original headers and unmodified product lines from both tables, in source encoding (Latin-1) and format (semicolon delimiter and decimal comma). source_manifest.json gives original download URLs, archive hashes, complete CSV member hashes, extract hashes and 1-based source lines counting the header as line 1. guides/ contains both distinct source guides. portal/ holds the full original total and all-countries query responses for each year. Files in the packet are listed in checksums.sha256. comparison/previous_annual.csv preserves the earlier two-country annual extract. Machine-readable output CSVs use UTF-8, decimal points, and blank fields for missing observations.
